<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ScriptDialog
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.SaveButton = New System.Windows.Forms.Button
        Me.Cancel_Button = New System.Windows.Forms.Button
        Me.PGrid = New System.Windows.Forms.DataGridView
        Me.ParameterColumn = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.ValueColumn = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.ScriptList = New System.Windows.Forms.ComboBox
        Me.ScriptGroup = New System.Windows.Forms.GroupBox
        Me.ParametersGroup = New System.Windows.Forms.GroupBox
        Me.RunButton = New System.Windows.Forms.Button
        CType(Me.PGrid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ScriptGroup.SuspendLayout()
        Me.ParametersGroup.SuspendLayout()
        Me.SuspendLayout()
        '
        'SaveButton
        '
        Me.SaveButton.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.SaveButton.Location = New System.Drawing.Point(327, 255)
        Me.SaveButton.Margin = New System.Windows.Forms.Padding(4)
        Me.SaveButton.Name = "SaveButton"
        Me.SaveButton.Size = New System.Drawing.Size(89, 28)
        Me.SaveButton.TabIndex = 0
        Me.SaveButton.Text = "Save"
        '
        'Cancel_Button
        '
        Me.Cancel_Button.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Cancel_Button.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Cancel_Button.Location = New System.Drawing.Point(424, 255)
        Me.Cancel_Button.Margin = New System.Windows.Forms.Padding(4)
        Me.Cancel_Button.Name = "Cancel_Button"
        Me.Cancel_Button.Size = New System.Drawing.Size(89, 28)
        Me.Cancel_Button.TabIndex = 1
        Me.Cancel_Button.Text = "Cancel"
        '
        'PGrid
        '
        Me.PGrid.AllowUserToAddRows = False
        Me.PGrid.AllowUserToDeleteRows = False
        Me.PGrid.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PGrid.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText
        Me.PGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.PGrid.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.ParameterColumn, Me.ValueColumn})
        Me.PGrid.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter
        Me.PGrid.Location = New System.Drawing.Point(6, 21)
        Me.PGrid.MultiSelect = False
        Me.PGrid.Name = "PGrid"
        Me.PGrid.RowHeadersVisible = False
        Me.PGrid.RowTemplate.Height = 24
        Me.PGrid.ShowCellErrors = False
        Me.PGrid.ShowEditingIcon = False
        Me.PGrid.ShowRowErrors = False
        Me.PGrid.Size = New System.Drawing.Size(495, 123)
        Me.PGrid.TabIndex = 2
        '
        'ParameterColumn
        '
        Me.ParameterColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.ParameterColumn.HeaderText = "Parameter"
        Me.ParameterColumn.MinimumWidth = 100
        Me.ParameterColumn.Name = "ParameterColumn"
        Me.ParameterColumn.ReadOnly = True
        '
        'ValueColumn
        '
        Me.ValueColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.ValueColumn.HeaderText = "Value"
        Me.ValueColumn.MinimumWidth = 50
        Me.ValueColumn.Name = "ValueColumn"
        Me.ValueColumn.Width = 69
        '
        'ScriptList
        '
        Me.ScriptList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ScriptList.FormattingEnabled = True
        Me.ScriptList.Location = New System.Drawing.Point(6, 21)
        Me.ScriptList.Name = "ScriptList"
        Me.ScriptList.Size = New System.Drawing.Size(495, 24)
        Me.ScriptList.TabIndex = 3
        '
        'ScriptGroup
        '
        Me.ScriptGroup.Controls.Add(Me.ScriptList)
        Me.ScriptGroup.Location = New System.Drawing.Point(12, 12)
        Me.ScriptGroup.Name = "ScriptGroup"
        Me.ScriptGroup.Size = New System.Drawing.Size(507, 64)
        Me.ScriptGroup.TabIndex = 4
        Me.ScriptGroup.TabStop = False
        Me.ScriptGroup.Text = "Select Script:"
        '
        'ParametersGroup
        '
        Me.ParametersGroup.Controls.Add(Me.PGrid)
        Me.ParametersGroup.Location = New System.Drawing.Point(12, 82)
        Me.ParametersGroup.Name = "ParametersGroup"
        Me.ParametersGroup.Size = New System.Drawing.Size(507, 159)
        Me.ParametersGroup.TabIndex = 5
        Me.ParametersGroup.TabStop = False
        Me.ParametersGroup.Text = "Edit Parameters"
        '
        'RunButton
        '
        Me.RunButton.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.RunButton.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.RunButton.Enabled = False
        Me.RunButton.Location = New System.Drawing.Point(230, 255)
        Me.RunButton.Margin = New System.Windows.Forms.Padding(4)
        Me.RunButton.Name = "RunButton"
        Me.RunButton.Size = New System.Drawing.Size(89, 28)
        Me.RunButton.TabIndex = 6
        Me.RunButton.Text = "Run"
        '
        'ScriptDialog
        '
        Me.AcceptButton = Me.SaveButton
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.Cancel_Button
        Me.ClientSize = New System.Drawing.Size(537, 304)
        Me.Controls.Add(Me.RunButton)
        Me.Controls.Add(Me.Cancel_Button)
        Me.Controls.Add(Me.SaveButton)
        Me.Controls.Add(Me.ParametersGroup)
        Me.Controls.Add(Me.ScriptGroup)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "ScriptDialog"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Script Config"
        CType(Me.PGrid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ScriptGroup.ResumeLayout(False)
        Me.ParametersGroup.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents SaveButton As System.Windows.Forms.Button
    Friend WithEvents Cancel_Button As System.Windows.Forms.Button
    Friend WithEvents PGrid As System.Windows.Forms.DataGridView
    Friend WithEvents ScriptList As System.Windows.Forms.ComboBox
    Friend WithEvents ScriptGroup As System.Windows.Forms.GroupBox
    Friend WithEvents ParametersGroup As System.Windows.Forms.GroupBox
    Friend WithEvents ParameterColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ValueColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents RunButton As System.Windows.Forms.Button

End Class
