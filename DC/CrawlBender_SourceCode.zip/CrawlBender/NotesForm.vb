Public Class NotesForm


#Region "Constants"

    Const ADD_LABEL = "Add"
    Const NEW_LABEL = "New"

    ' tab text values
    Const SCROLL_TAB = "Scrolls"
    Const POTION_TAB = "Potions"
    Const RING_TAB = "Rings"
    Const WAND_TAB = "Wands"
    Const AMULET_TAB = "Amulets"
    Const MISC_TAB = "Misc"

#End Region



#Region "Private members"

    ''' <summary>
    ''' current character's notes file
    ''' </summary>
    Private _notes As CharacterNotes

    Private _unsavedChanges As Boolean = False

#End Region



#Region "Properties"

    ''' <summary>
    ''' return currently selected note from the active listbox
    ''' </summary>
    Private ReadOnly Property SelectedNote() As Note
        Get
            Try
                Select Case NotesTabs.SelectedTab.Text
                    Case SCROLL_TAB : Return ScrollsList.SelectedItem
                    Case POTION_TAB : Return PotionsList.SelectedItem
                    Case RING_TAB : Return RingsList.SelectedItem
                    Case WAND_TAB : Return WandsList.SelectedItem
                    Case AMULET_TAB : Return AmuletsList.SelectedItem
                    Case MISC_TAB : Return MiscList.SelectedItem
                    Case Else
                        Return Nothing
                End Select
            Catch ex As Exception
                Return Nothing
            End Try
        End Get
    End Property


    ''' <summary>
    ''' select the notes list based on which tab is active
    ''' </summary>
    Private ReadOnly Property SelectedNotes()
        Get
            Select Case NotesTabs.SelectedTab.Text
                Case SCROLL_TAB : Return _notes.Scrolls
                Case POTION_TAB : Return _notes.Potions
                Case RING_TAB : Return _notes.Rings
                Case WAND_TAB : Return _notes.Wands
                Case AMULET_TAB : Return _notes.Amulets
                Case MISC_TAB : Return _notes.Misc
                Case Else
                    Return Nothing
            End Select
        End Get
    End Property

#End Region



#Region "Public Methods"

    ''' <summary>
    ''' open saved note file and load into Note toolbox
    ''' </summary>
    ''' <param name="FullFileName">full path of note's file name</param>
    Public Sub LoadNotes(ByVal FullFileName As String)


        _notes = New CharacterNotes(FullFileName)

        With My.Computer.FileSystem
            If _notes.FileExists Then

                _notes.Load()
                RefreshAllLists()

            Else 'prompt user to create a file 

                Dim response As DialogResult = MessageBox.Show(FullFileName & " not found.  Would you like to create it?", "Create New Notes file?", MessageBoxButtons.OKCancel)
                If response = Windows.Forms.DialogResult.OK Then
                    _notes.Create()
                Else
                    Me.Close()
                End If
            End If
        End With

    End Sub


#End Region



#Region "Private Procedures"

    ''' <summary>
    ''' clear all lists and reassociate them to their appropriate data sources (this will display any changes to notes lists)
    ''' </summary>
    Private Sub RefreshAllLists()

        ScrollsList.DataSource = Nothing
        ScrollsList.DataSource = _notes.Scrolls

        PotionsList.DataSource = Nothing
        PotionsList.DataSource = _notes.Potions

        RingsList.DataSource = Nothing
        RingsList.DataSource = _notes.Rings

        WandsList.DataSource = Nothing
        WandsList.DataSource = _notes.Wands

        AmuletsList.DataSource = Nothing
        AmuletsList.DataSource = _notes.Amulets

        MiscList.DataSource = Nothing
        MiscList.DataSource = _notes.Misc

    End Sub


    ''' <summary>
    ''' populate the Item name and description text boxes from the curretnly selected note
    ''' </summary>
    Private Sub PopTextboxes()
        Dim nt As Note = SelectedNote
        If nt Is Nothing Then
            Title.Enabled = False
            Content.Enabled = False
            Title.Text = ""
            Content.Text = ""
        Else
            Title.Enabled = True
            Content.Enabled = True
            Title.Text = nt.Title
            Content.Text = nt.Content

            AddButton.Text = NEW_LABEL
        End If

        
    End Sub

#End Region



#Region "Event Handlers"


    Private Sub NotesForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.Text = _notes.Filename_NoPath
        RefreshAllLists()
    End Sub


    ''' <summary>
    ''' pop text boxes whenever the selected note changes
    ''' </summary>
    Private Sub AnyList_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ScrollsList.SelectedIndexChanged, PotionsList.SelectedIndexChanged, RingsList.SelectedIndexChanged, WandsList.SelectedIndexChanged, AmuletsList.SelectedIndexChanged, MiscList.SelectedIndexChanged
        PopTextboxes()
    End Sub
    Private Sub NotesTabs_Selected(ByVal sender As Object, ByVal e As System.Windows.Forms.TabControlEventArgs) Handles NotesTabs.Selected
        PopTextboxes()
    End Sub


    ''' <summary>
    ''' prompt user to save any unsaved data
    ''' </summary>
    Private Sub NotesForm_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing

        If _unsavedChanges Then

            Dim result As DialogResult = MessageBox.Show("This notes file has unsaved data.  Do you want to saved it before closing?", "Unsaved Notes", MessageBoxButtons.YesNoCancel)

            If result = Windows.Forms.DialogResult.Cancel Then
                e.Cancel = True
            ElseIf result = Windows.Forms.DialogResult.Yes Then
                _notes.Save()
            End If

        End If
    End Sub


    'buttons
    Private Sub AddButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddButton.Click

        If AddButton.Text = NEW_LABEL Then 'clear text boxes set button text to "Add"
            AddButton.Text = ADD_LABEL

            Title.Text = ""
            Content.Text = ""
            Title.Enabled = True
            Content.Enabled = True
            Title.Focus()

        Else 'build note from textboxes and added it to the notes list associated with the currently selected listbox

            Me.SelectedNotes.Add(New Note(Title.Text, Content.Text))
            _unsavedChanges = True
            RefreshAllLists()
            AddButton.Text = NEW_LABEL
        End If

    End Sub
    Private Sub UpdateButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UpdateButton.Click
        Dim nt As Note = SelectedNote
        If nt IsNot Nothing Then
            nt.Title = Title.Text
            nt.Content = Content.Text
            RefreshAllLists()
            _unsavedChanges = True
        End If
    End Sub
    Private Sub DeleteButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DeleteButton.Click
        Dim nt As Note = SelectedNote
        If nt IsNot Nothing Then
            Me.SelectedNotes.Remove(nt)
            _unsavedChanges = True
            RefreshAllLists()
        End If
    End Sub
    Private Sub SaveBut_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveBut.Click
        Me._notes.Save()
        _unsavedChanges = False
    End Sub


#End Region













   
End Class