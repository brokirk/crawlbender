Imports CrawlBender.Script

''' <summary>
''' Parses and runs commands in a script
''' </summary>
Public Class ScriptEngine


#Region "Constants"

    Private Const SPACE_BAR = " "

    Public Enum Directions
        West
        East
        North
        South
        Ascend
        Descend
        NW
        NE
        SW
        SE
    End Enum

    'aquirement scroll options
    Public Const AQUIRE_WEAPON = "a"
    Public Const AQUIRE_ARMOUR = "b"
    Public Const AQUIRE_JEWELLERY = "c"
    Public Const AQUIRE_BOOK = "d"
    Public Const AQUIRE_STAFF = "e"
    Public Const AQUIRE_FOOD = "f"
    Public Const AQUIRE_MISC = "g"
    Public Const AQUIRE_GOLD = "h"

    'text displayed to user
    Public Const REPS_TEXT As String = "Iterations"
    Public Const SPELL_TEXT As String = "Spell Letter"
    Public Const SCROLL_TEXT As String = "Scroll Letter"
    Public Const BOOK_TEXT As String = "Book Letter"
    Public Const POTIONS_TEXT As String = "Potion Letter"
    Public Const THING_TEXT As String = "Type (a-h)"
    Public Const PAUSE_TEXT As String = "Pause between iterations (in MS)"


    ''index of parameters in parameters list
    'Public Const BRIBE_REPS_INDX = 0
    'Public Const BRIBE_PAUSE_INDX = 1

    'Public Const CAST_SPELL_INDX = 0
    'Public Const CAST_REPS_INDX = 1
    'Public Const CAST_PAUSE_INDX = 2

    'Public Const READ_SCROLL_INDX = 0
    'Public Const READ_REPS_INDX = 1
    'Public Const READ_PAUSE_INDX = 2

    'Public Const MEMO_BOOK_INDX = 0
    'Public Const MEMO_SPELL_INDX = 1
    'Public Const MEMO_REPS_INDX = 2
    'Public Const MEMO_PAUSE_INDX = 3

    'Public Const ENVOKE_REPS_INDX = 0
    'Public Const ENVOKE_PAUSE_INDX = 1

    'Public Const QUAFF_POTIONS_INDX = 0
    'Public Const QUAFF_REPS_INDX = 1
    'Public Const QUAFF_PAUSE_INDX = 2

    'Public Const AQUIRE_SCROLL_INDX = 0
    'Public Const AQUIRE_THING_INDX = 1
    'Public Const AQUIRE_REPS_INDX = 2
    'Public Const AQUIRE_PAUSE_INDX = 3

    'crawl commands
    Const CRAWL_READ = "r"
    Const CRAWL_PICKUP = ","
    Const CRAWL_EXAMINE = "x"
    Const CRAWL_DROP = "d"
    Const CRAWL_PRAY = "p"
    Const CRAWL_MEMORIZE = "M"
    Const CRAWL_CAST = "Z"
    Const CRAWL_EVOKE = "E"
    Const CRAWL_QUAFF = "q"
    Const CRAWL_LIST_ABILITIES = "A"
    Const CRAWL_VIEW_ITEM = "v"

#End Region



#Region "Private Members"
    ''' <summary>
    ''' reference to the main form (used when access app commands)
    ''' </summary>
    Private _mainForm As MainForm


#End Region



#Region "Properties"

    ''' <summary>
    ''' value in title bar for DC app
    ''' </summary>
    ''' <remarks></remarks>
    Public DCTitle As String = "Crawl 4.0.0 beta 26"

#End Region


#Region "Public Methods"

    Public Sub New(ByRef BenderWindow As MainForm)
        _mainForm = BenderWindow
    End Sub

    Public Sub RunScript(ByRef Script2Run As Script)

        Select Case Script2Run.ScriptType

            Case ScriptTypes.Bribe_a_Thon
                'Dim reps As Integer = Str2Num(Script2Run.Parameters(BRIBE_REPS_INDX))
                'Dim pauseMS As Integer = Str2Num(Script2Run.Parameters(BRIBE_PAUSE_INDX))
                Dim reps As Integer = Str2Num(Script2Run.Iterations)
                Dim pauseMS As Integer = Str2Num(Script2Run.Pause_MS)
                Me.Bribe_A_Thon(reps, pauseMS)

            Case ScriptTypes.ReadScroll

                'Dim scroll As String = Script2Run.Parameters(READ_SCROLL_INDX)
                'Dim reps As Integer = Str2Num(Script2Run.Parameters(READ_REPS_INDX))
                'Dim pauseMS As Integer = Str2Num(Script2Run.Parameters(READ_PAUSE_INDX))
                Dim scroll As String = CType(Script2Run, ReadScrollScript).ScrollLetter
                Dim reps As Integer = Str2Num(Script2Run.Iterations)
                Dim pauseMS As Integer = Str2Num(Script2Run.Pause_MS)
                Me.LeggerePergamena(scroll, reps, pauseMS)

            Case ScriptTypes.MemorizeSpell
                Dim book As String = CType(Script2Run, MemorizeSpellScript).BookLetter
                Dim spell As String = CType(Script2Run, MemorizeSpellScript).SpellLetter
                Dim reps As Integer = Str2Num(Script2Run.Iterations)
                Dim pauseMS As Integer = Str2Num(Script2Run.Pause_MS)
                Me.MemorizzareIncantesimo(book, spell, reps, pauseMS)

            Case ScriptTypes.CastSpell
                Dim spell As String = CType(Script2Run, CastSpellScript).SpellLetter
                Dim reps As Integer = Str2Num(Script2Run.Iterations)
                Dim pauseMS As Integer = Str2Num(Script2Run.Pause_MS)
                Me.LanciareIncantesimo(spell, reps, pauseMS)

            Case ScriptTypes.Envoke
                Dim reps As Integer = Str2Num(Script2Run.Iterations)
                Dim pauseMS As Integer = Str2Num(Script2Run.Pause_MS)
                Me.Evocare(reps, pauseMS)

            Case ScriptTypes.Quaff
                Dim potion As String = CType(Script2Run, QuaffScript).PotionLetter
                Dim reps As String = Str2Num(Script2Run.Iterations)
                Dim pauseMS As Integer = Str2Num(Script2Run.Pause_MS)
                Me.Quaff(potion, reps, pauseMS)

            Case ScriptTypes.ScrollOfAquirement
                Dim scroll As String = CType(Script2Run, ScrollOfAquirementScript).ScrollLetter
                Dim thing As String = CType(Script2Run, ScrollOfAquirementScript).ThingLetter
                Dim reps As String = Str2Num(Script2Run.Iterations)
                Dim pauseMS As Integer = Str2Num(Script2Run.Pause_MS)
                Me.PergamenaDiAquirement(scroll, thing, reps, pauseMS)


        End Select

    End Sub

    



#End Region



#Region "Private Procedures"

    ' Get a handle to an application window.
    Declare Auto Function FindWindow Lib "USER32.DLL" (ByVal lpClassName As String, ByVal lpWindowName As String) As IntPtr

    ' Activate an application window.
    Declare Auto Function SetForegroundWindow Lib "USER32.DLL" (ByVal hWnd As IntPtr) As Boolean

    ''' <summary>
    ''' convert string to number (handle blanks and non-numerics) 
    ''' </summary>
    Private Function Str2Num(ByVal Str As String) As Integer
        Dim num As Integer = 1
        If Str.Trim = "" Or Not IsNumeric(Str.Trim) Then
            num = 1
        Else
            num = CInt(Str)
        End If
        Return num
    End Function

    ''' <summary>
    ''' send the keystroke 
    ''' </summary>
    ''' <param name="key"></param>    
    Sub Premere(ByVal key As String)
        SendKeys.SendWait(key)
        Pause(200)
    End Sub

    ''' <summary>
    ''' give Crawl focus
    ''' </summary>
    ''' <remarks></remarks>
    Sub AttivareCrawl()
        'Shell.AppActivate(DCTitle)
        Dim appHandle As IntPtr = FindWindow("ConsoleWindowClass", DCTitle)

        '' Verify that Crawl is a running process.
        'If appHandle = IntPtr.Zero Then
        '    MsgBox(DCTitle & " is not running.")
        '    Exit Sub
        'End If

        ' Make Crawl the foreground application 
        SetForegroundWindow(appHandle)
        Pause(100)
    End Sub

    ''' <summary>
    ''' give Crawl Bender focus
    ''' </summary>
    Sub AttivareAiutante()
        'shell.AppActivate("Crawl Bender")
        _mainForm.Focus()

        Pause(100)
    End Sub

    ''' <summary>
    ''' Launch Dungeon Crawl
    ''' </summary>
    ''' <remarks></remarks>
    Sub LanciareCrawl()
        'Premere("^l")
        Me._mainForm.LoadSavedGame()
    End Sub

    ''' <summary>
    ''' Pause app execution for short time
    ''' </summary>
    ''' <param name="TimeInMs"></param>
    ''' <remarks></remarks>
    Sub Pause(ByVal TimeInMs)
        'WScript.sleep(TimeInMs)
        If TimeInMs >= 50 Then
            System.Threading.Thread.Sleep(TimeInMs)
        End If
    End Sub

    ''' <summary>
    ''' Save the game
    ''' </summary>
    Sub ConservareGioco()
        Premere("S")
        Premere("Y")
    End Sub


    ''' <summary>
    ''' move one step to Direction 
    ''' </summary>
    ''' <param name="Direzione"></param>
    Public Sub Andare(ByVal Direzione As Directions)

        Select Case Direzione
            Case Directions.West : Premere("{LEFT}")
            Case Directions.East : Premere("{RIGHT}")
            Case Directions.North : Premere("{UP}")
            Case Directions.South : Premere("{DOWN}")
            Case Directions.NW : Premere("{HOME}")
            Case Directions.NE : Premere("{PGUP}")
            Case Directions.SW : Premere("{END}")
            Case Directions.SE : Premere("{PGDN}")
            Case Directions.Ascend : Premere("<")
            Case Directions.Descend : Premere(">")
        End Select
    End Sub



#End Region

#Region "Command Line Procedures"

    ''' <summary>
    '''  parse and run the commnd line 
    ''' </summary>    
    ''' <remarks>
    ''' P(x) = Push key 'x'
    ''' [command] = run 'command' macro
    '''   macros: launch, backup, 
    ''' 
    ''' semi-colon delimited?
    ''' 
    ''' </remarks>
    Public Sub ParseCmdLine(ByVal cmdLineString As String)

        Const DLMTR = ";"

        Dim cmds() As String = cmdLineString.Split(DLMTR)
        For Each cmd As String In cmds
            If IsBigPush(cmd) Then
                BigPushViaCmdLine(GetKeyToPush(cmd))
            ElseIf IsLittlePush(cmd) Then
                LittlePushViaCmdLine(GetKeyToPush(cmd))
            ElseIf IsScript(cmd) Then
                Dim mac As String = GetScriptCommand(cmd)
                MsgBox("run " & mac)
            End If
        Next

    End Sub

    ''' <summary>
    ''' push key after launch new crawl
    ''' </summary>    
    Private Sub BigPushViaCmdLine(ByVal key As String)
        AttivareAiutante()
        LanciareCrawl()
        AttivareCrawl()
        Pause(250)
        Premere(key)
    End Sub

    ''' <summary>
    ''' push key in existing crawl
    ''' </summary>    
    Private Sub LittlePushViaCmdLine(ByVal key As String)
        AttivareCrawl()
        Pause(250)
        Premere(key)
    End Sub

    ''' <summary>
    ''' parse "P(x)" to get the "x" out
    ''' </summary>    
    Private Function GetKeyToPush(ByVal cmd As String) As String
        cmd = cmd.Replace("P(", "").Replace("p(", "")
        cmd = cmd.Substring(0, cmd.Length - 1)
        Return cmd
    End Function


    ''' <summary>
    ''' parse "[script]" to get "script" command out
    ''' </summary>    
    Private Function GetScriptCommand(ByVal cmd As String) As String
        Return cmd.Replace("[", "").Replace("]", "")
    End Function

    ''' <summary>
    ''' test if command string is a "little Push" command; little push means push key in existing 
    ''' crawl
    ''' </summary>    
    Private Function IsLittlePush(ByVal cmd As String) As Boolean
        If cmd.StartsWith("p(") Then
            Return True
        Else
            Return False
        End If
    End Function

    ''' <summary>
    ''' test if command string is a "Big Push; big push means launch new crawl and then push key
    ''' </summary>    
    Private Function IsBigPush(ByVal cmd As String) As Boolean
        If cmd.StartsWith("P(") Then
            Return True
        Else
            Return False
        End If
    End Function

    ''' <summary>
    ''' test if command string is a script command
    ''' </summary>
    Private Function IsScript(ByVal cmd As String) As Boolean
        If cmd.StartsWith("[") Then
            Return True
        Else
            Return False
        End If
    End Function

#End Region




#Region "Script Commands"

    ''' <summary>
    ''' launch a new crawl session then read ScrollLetter; repeated Ripetizione times
    ''' </summary>
    ''' <param name="ScrollLettera"></param>
    ''' <param name="Ripetizioni"></param>
    ''' <remarks></remarks>
    Public Sub LeggerePergamena(ByVal ScrollLettera As String, ByVal Ripetizioni As Integer, Optional ByVal PauseMS As Integer = 0)
        Dim i
        For i = 1 To Ripetizioni
            Me._mainForm.ScriptButton.Text = i & "/" & Ripetizioni
            AttivareAiutante()
            LanciareCrawl()
            AttivareCrawl()
            Premere("r")
            Premere(ScrollLettera)
            Pause(PauseMS)
        Next
    End Sub


    ''' <summary>
    ''' bribe your Power with gold (saving each time)
    ''' </summary>
    ''' <param name="Ripetizioni"></param>
    Sub Bribe_A_Thon(ByVal Ripetizioni As Integer, Optional ByVal PauseMS As Integer = 750)

        For i As Integer = 1 To Ripetizioni

            Me._mainForm.ScriptButton.Text = i & "/" & Ripetizioni

            AttivareAiutante()
            Me._mainForm.FixGold()      'Premere("^g")
            LanciareCrawl()
            AttivareCrawl()
            Premere(CRAWL_DROP)
            Premere(SPACE_BAR)
            Premere(SPACE_BAR)
            Premere("$")
            Premere(CRAWL_PRAY)

            'check for min pause time
            If PauseMS < 200 Then
                Pause(750)
            Else
                Pause(PauseMS)
            End If

            'pick up anything you may have been granted
            Premere(",")

            ConservareGioco()
        Next
    End Sub

    ''' <summary>
    ''' launch crawl and attempt to memorize a spell repeatedly without saving
    ''' </summary>
    ''' <param name="LibroLettera">Book letter</param>
    ''' <param name="IncantesimoLettera">Spell letter</param>
    ''' <param name="Ripetizioni"></param>
    ''' <remarks></remarks>
    Public Sub MemorizzareIncantesimo(ByVal LibroLettera As String, ByVal IncantesimoLettera As String, ByVal Ripetizioni As Integer, Optional ByVal PauseMS As Integer = 0)

        For i As Integer = 1 To Ripetizioni
            Me._mainForm.ScriptButton.Text = i & "/" & Ripetizioni
            AttivareAiutante()
            LanciareCrawl()
            AttivareCrawl()
            Premere(CRAWL_MEMORIZE)
            Premere(LibroLettera)
            Premere(IncantesimoLettera)
            Premere("y") 'y = yes
            Pause(PauseMS)
        Next
    End Sub


    ''' <summary>
    ''' launch crawl and cast spell repeatedly without saving
    ''' </summary>
    ''' <param name="IncantesimoLettera">Spell letter</param>
    ''' <param name="Ripetizioni"></param>
    Public Sub LanciareIncantesimo(ByVal IncantesimoLettera As String, ByVal Ripetizioni As Integer, Optional ByVal PauseMS As Integer = 0)

        For i As Integer = 1 To Ripetizioni
            Me._mainForm.ScriptButton.Text = i & "/" & Ripetizioni
            AttivareAiutante()
            LanciareCrawl()
            AttivareCrawl()
            Premere(CRAWL_CAST)
            Premere(IncantesimoLettera)
            Pause(PauseMS)
        Next
    End Sub


    ''' <summary>
    ''' launch crawl and evoke power of held object repeatedly without saving
    ''' </summary>
    ''' <param name="Ripetizioni"></param>
    Public Sub Evocare(ByVal Ripetizioni As Integer, Optional ByVal PauseMS As Integer = 0)

        For i As Integer = 1 To Ripetizioni
            Me._mainForm.ScriptButton.Text = i & "/" & Ripetizioni
            AttivareAiutante()
            LanciareCrawl()
            AttivareCrawl()
            Premere(CRAWL_EVOKE)
            Pause(PauseMS)
        Next
    End Sub


    ''' <summary>
    ''' launch crawl and drink potion repeatedly without saving
    ''' </summary>
    ''' <param name="PotionLettera">Potion Letter</param>
    ''' <param name="Ripetizioni"></param>
    ''' <remarks></remarks>
    Public Sub Quaff(ByVal PotionLettera As String, ByVal Ripetizioni As Integer, Optional ByVal PauseMS As Integer = 2500)

        For i As Integer = 1 To Ripetizioni
            Me._mainForm.ScriptButton.Text = i & "/" & Ripetizioni
            AttivareAiutante()
            LanciareCrawl()
            AttivareCrawl()
            Premere(CRAWL_QUAFF)
            Premere(PotionLettera)
            Premere(SPACE_BAR)
            Premere(CRAWL_LIST_ABILITIES)

            'check for min pause time
            If PauseMS < 200 Then
                Pause(2500)
            Else
                Pause(PauseMS)
            End If

        Next
    End Sub

    ''' <summary>
    ''' Read scroll of aquirement repeatly with out saving
    ''' </summary>
    ''' <param name="PergamenaLettera">Scroll Letter</param>
    ''' <param name="OptionLettera"></param>
    ''' <param name="Ripetizioni"></param>
    ''' <remarks></remarks>
    Public Sub PergamenaDiAquirement(ByVal PergamenaLettera As String, ByVal OptionLettera As String, ByVal Ripetizioni As Integer, Optional ByVal PauseMS As Integer = 500)

        For i As Integer = 1 To Ripetizioni
            Me._mainForm.ScriptButton.Text = i & "/" & Ripetizioni
            AttivareAiutante()
            LanciareCrawl()
            AttivareCrawl()
            Pause(250)

            Premere(CRAWL_READ)
            Premere(PergamenaLettera)
            Premere(OptionLettera)
            Premere(CRAWL_PICKUP)
            Premere(CRAWL_VIEW_ITEM)
            Dim newItemLetter As String = PergamenaLettera
            Premere(newItemLetter)

            'check for min pause time
            If PauseMS < 200 Then
                Pause(500)
            Else
                Pause(PauseMS)
            End If

        Next

    End Sub

#End Region



End Class





''' <summary>
''' A script command and it associated parameters
''' </summary>
Public MustInherit Class Script

#Region "Const"

    Public Enum ScriptTypes
        None = -1
        Bribe_a_Thon = 0
        ReadScroll = 1
        MemorizeSpell = 2
        CastSpell = 3
        Envoke = 4
        Quaff = 5
        ScrollOfAquirement = 6
    End Enum

#End Region


#Region "Properties"

    Public MustOverride ReadOnly Property ScriptType() As ScriptTypes

    ''' <summary>
    ''' number of times to repeat the script (DEFAULT = 5)
    ''' </summary>
    Public Iterations As Integer = 5

    ''' <summary>
    ''' pause in milliseconds between runs of the script (DEFAULT = 500ms)
    ''' </summary>
    Public Pause_MS As Integer = 500

    'Private _scriptType As ScriptTypes = ScriptTypes.None
    'Public Property ScriptType() As ScriptTypes
    '    Get
    '        Return _scriptType
    '    End Get
    '    Set(ByVal value As ScriptTypes)
    '        'Parameters.Clear() 'reset saved parameters because type changed.
    '        If value <> Me._scriptType Then Me.Parameters = New List(Of String)
    '        _scriptType = value
    '    End Set
    'End Property

    'Public Parameters As New List(Of String)

#End Region


#Region "Methods"

    Public MustOverride Sub DeepCopy(ByRef SrcScript As Script)

#End Region


End Class


'Bribe_a_Thon = 0
'ReadScroll = 1
'MemorizeSpell = 2
'CastSpell = 3
'Envoke = 4
'Quaff = 5
'ScrollOfAquirement = 6

Public Class BribeScript
    Inherits Script

    Public Overrides ReadOnly Property ScriptType() As ScriptTypes
        Get
            Return ScriptTypes.Bribe_a_Thon
        End Get
    End Property

    Public Overrides Sub DeepCopy(ByRef SrcScript As Script)
        Me.Iterations = SrcScript.Iterations
        Me.Pause_MS = SrcScript.Pause_MS
    End Sub

End Class


Public Class ReadScrollScript
    Inherits Script

    Public Overrides ReadOnly Property ScriptType() As Script.ScriptTypes
        Get
            Return ScriptTypes.ReadScroll
        End Get
    End Property

    Public ScrollLetter As String = ""

    Public Overrides Sub DeepCopy(ByRef SrcScript As Script)
        Me.ScrollLetter = CType(SrcScript, ReadScrollScript).ScrollLetter
        Me.Iterations = SrcScript.Iterations
        Me.Pause_MS = SrcScript.Pause_MS
    End Sub

End Class


Public Class MemorizeSpellScript
    Inherits Script

    Public Overrides ReadOnly Property ScriptType() As Script.ScriptTypes
        Get
            Return ScriptTypes.MemorizeSpell
        End Get
    End Property

    Public BookLetter As String = ""

    Public SpellLetter As String = ""

    Public Overrides Sub DeepCopy(ByRef SrcScript As Script)
        Me.BookLetter = CType(SrcScript, MemorizeSpellScript).BookLetter
        Me.SpellLetter = CType(SrcScript, MemorizeSpellScript).SpellLetter
        Me.Iterations = SrcScript.Iterations
        Me.Pause_MS = SrcScript.Pause_MS
    End Sub

End Class


Public Class CastSpellScript
    Inherits Script

    Public Overrides ReadOnly Property ScriptType() As Script.ScriptTypes
        Get
            Return ScriptTypes.CastSpell
        End Get
    End Property

    Public SpellLetter As String = ""

    Public Overrides Sub DeepCopy(ByRef SrcScript As Script)
        Me.SpellLetter = CType(SrcScript, CastSpellScript).SpellLetter
        Me.Iterations = SrcScript.Iterations
        Me.Pause_MS = SrcScript.Pause_MS
    End Sub

End Class


''' <summary>
''' envoke the currently held item
''' </summary>
Public Class EnvokeScript
    Inherits Script

    Public Overrides ReadOnly Property ScriptType() As Script.ScriptTypes
        Get
            Return ScriptTypes.Envoke
        End Get
    End Property

    Public Overrides Sub DeepCopy(ByRef SrcScript As Script)
        Me.Iterations = SrcScript.Iterations
        Me.Pause_MS = SrcScript.Pause_MS
    End Sub

End Class


Public Class QuaffScript
    Inherits Script

    Public Overrides ReadOnly Property ScriptType() As Script.ScriptTypes
        Get
            Return ScriptTypes.Quaff
        End Get
    End Property

    Public PotionLetter As String = ""

    Public Overrides Sub DeepCopy(ByRef SrcScript As Script)
        Me.PotionLetter = CType(SrcScript, QuaffScript).PotionLetter
        Me.Iterations = SrcScript.Iterations
        Me.Pause_MS = SrcScript.Pause_MS
    End Sub

End Class


Public Class ScrollOfAquirementScript
    Inherits Script

    Public Overrides ReadOnly Property ScriptType() As Script.ScriptTypes
        Get
            Return ScriptTypes.ScrollOfAquirement
        End Get
    End Property

    Public ScrollLetter As String = ""

    ''' <summary>
    ''' Letter of the type of aquirement (a through f)
    ''' </summary>
    Public ThingLetter As String = ""

    Public Overrides Sub DeepCopy(ByRef SrcScript As Script)
        Me.ScrollLetter = CType(SrcScript, ScrollOfAquirementScript).ScrollLetter
        Me.ThingLetter = CType(SrcScript, ScrollOfAquirementScript).ThingLetter
        Me.Iterations = SrcScript.Iterations
        Me.Pause_MS = SrcScript.Pause_MS
    End Sub

End Class

