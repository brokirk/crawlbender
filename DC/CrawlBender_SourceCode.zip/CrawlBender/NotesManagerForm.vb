Imports System.IO.Path
Public Class NotesManagerForm

#Region "Private Members"
    Private _path As String = ""
#End Region



#Region "Form"

    Public Sub New(ByVal NotesFolderPath As String)

        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        _path = NotesFolderPath
    End Sub

    Private Sub NotesManagerForm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        PopNotesFileList()
    End Sub

#End Region



#Region "Buttons"

    Private Sub NewButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NewButton.Click

    End Sub

    Private Sub OpenButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OpenButton.Click

        OpenButton.Enabled = False
        '[] get file name
        Dim fname As String = NotesList.SelectedItem
        fname = Combine(_path, fname)

        ' open file
        Shell("Notepad.exe " & fname, AppWinStyle.NormalFocus)

        OpenButton.Enabled = True

    End Sub

    Private Sub DeleteButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DeleteButton.Click

        DeleteButton.Enabled = False

        'delete file
        Dim fname As String = Combine(_path, NotesList.SelectedItem)

        Try
            My.Computer.FileSystem.DeleteFile(fname, FileIO.UIOption.AllDialogs, FileIO.RecycleOption.DeletePermanently)
        Catch cancelEx As OperationCanceledException 'do nothing if user cancels
            'MessageBox.Show(cancelEx.ToString)  
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
        End Try

        'refresh list
        PopNotesFileList()

        DeleteButton.Enabled = True
    End Sub

    Private Sub RefreshButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RefreshButton.Click
        RefreshButton.Enabled = False
        PopNotesFileList()
        RefreshButton.Enabled = True
    End Sub

    Private Sub EnableButtons()
        If NotesList.SelectedIndex >= 0 Then
            OpenButton.Enabled = True
            DeleteButton.Enabled = True
        Else
            OpenButton.Enabled = False
            DeleteButton.Enabled = False
        End If
    End Sub


#End Region



#Region "File List Box"

    Private Sub NotesList_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NotesList.SelectedIndexChanged
        EnableButtons()
    End Sub

    Private Sub PopNotesFileList()
        NotesList.Items.Clear()
        For Each f As String In My.Computer.FileSystem.GetFiles(_path)
            NotesList.Items.Add(GetFileName(f))
        Next

        EnableButtons()
    End Sub

#End Region




    
End Class