Imports System.Windows.Forms
Imports System.IO.Path

Public Class OptionsDialog

#Region "Private Members"
    Private _options As GameOptions
#End Region


#Region "Properties"

#End Region



#Region "Class/form"

    Public Sub New(ByRef Ops As GameOptions)

        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        _options = Ops
    End Sub

    Private Sub OptionsDialog_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        PopCurrentSettings()
    End Sub

#End Region



#Region "Button Events"

    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click
        Dim isValid As Boolean = False
        ValidateSettings(isValid)
        If isValid Then
            Me.DialogResult = System.Windows.Forms.DialogResult.OK
            Me.Close()
        End If
    End Sub

    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub

    Private Sub GamePathButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GamePathButton.Click
        GamePathText.Text = SelectPath("Select Game Path", GamePathText.Text)
    End Sub

    Private Sub SelectGameNotes_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SelectGameNotes.Click
        With SelectFileDialog
            .CheckFileExists = True
            .Multiselect = False
            .RestoreDirectory = True
            .Title = "Select Game Notes File"
            .FileName = GameOptions.DEFAULT_GAME_NOTES
            If .ShowDialog() = Windows.Forms.DialogResult.OK Then
                GameNotesText.Text = .FileName
            End If
        End With
    End Sub

    Private Sub BackupPathButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BackupPathButton.Click
        BackupPathText.Text = SelectPath("Select Backup Path", BackupPathText.Text)
    End Sub

    Private Sub NotesPathButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NotesPathButton.Click
        NotesPathText.Text = SelectPath("Select Notes Path", NotesPathText.Text)
    End Sub

#End Region



#Region "Private Procedures"

    Private Function SelectPath(ByVal Title As String, Optional ByVal StartFolder As String = "") As String
        With FolderDialog
            .Description = Title
            If My.Computer.FileSystem.DirectoryExists(StartFolder) Then .SelectedPath = StartFolder

            If .ShowDialog() = Windows.Forms.DialogResult.OK Then
                Return .SelectedPath
            Else
                Return StartFolder
            End If
        End With
    End Function

    Private Sub PopCurrentSettings()

        Me.GamePathText.Text = _options.GamePath ' My.Settings.GameFolder
        Me.NotesPathText.Text = _options.NotesPath
        Me.BackupPathText.Text = _options.BackupPath
        Me.GameNotesText.Text = _options.GameNotes

    End Sub

    Private Sub SaveSettings()
        My.Settings.GameFolder = Me.GamePathText.Text
        My.Settings.NotesFolder = Me.NotesPathText.Text
        My.Settings.BackupFolder = Me.BackupPathText.Text
        My.Settings.GamesNotes = Me.GameNotesText.Text
        My.Settings.Save()
    End Sub

    Private Sub ValidateSettings(ByRef IsValid As Boolean)
        IsValid = False
        With My.Computer.FileSystem

            If Not .DirectoryExists(Me.GamePathText.Text) Then
                MessageBox.Show(Me.GamePathText.Text & " not found", "Game Path Invalid")
                GamePathText.Focus()
                Exit Sub
            End If

            If Not .DirectoryExists(NotesPathText.Text) Then
                MessageBox.Show(NotesPathText.Text & " not found", "Notes Path Invalid")
                NotesPathText.Focus()
                Exit Sub
            End If

            If Not .DirectoryExists(BackupPathText.Text) Then
                MessageBox.Show(BackupPathText.Text & " not found", "Backup Path Invalid")
                BackupPathText.Focus()
                Exit Sub
            End If

            If Not .DirectoryExists(Combine(NotesPathText.Text, GameNotesText.Text)) Then
                MessageBox.Show(GameNotesText.Text & " not found", "Game Notes File Name Invalid")
                GameNotesText.Focus()
                Exit Sub
            End If
        End With
        IsValid = True
    End Sub

#End Region



End Class
