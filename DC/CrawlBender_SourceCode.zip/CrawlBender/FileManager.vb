Imports System.IO.Path
Public Class CrawlFileManager

    Const MOURGE_FNAME = "morgue.txt"

#Region "Private Members"
    Private _savedPath As String
    Private _backupPath As String
#End Region

#Region "Public Methods"

    Public Sub New(ByVal GameFolder As String, ByVal BackupFolder As String)
        _savedPath = GameFolder
        _backupPath = BackupFolder
    End Sub


    ''' <summary>
    ''' move all file related to SavedGameName from saved folder to backup game folder; return number of files moved
    ''' </summary>
    ''' <param name="SavedGameName"></param>
    ''' <param name="ProgBar">reference to a progress bar control</param>
    Public Function Backup(ByVal SavedGameName As String, ByRef ProgBar As ProgressBar) As Integer

        Return MoveCharacter(SavedGameName, _savedPath, _backupPath, ProgBar)

        'Dim nameNoExt As String = GetFileNameWithoutExtension(SavedGameName)

        ''CopyFiles(Me._savedPath, Me._backupPath, nameNoExt)
        ''-=-=-=-=-=-=
        'ProgBar.Value = 0
        'ProgBar.Visible = True
        ''
        'Dim files As System.Collections.ObjectModel.ReadOnlyCollection(Of String) = My.Computer.FileSystem.GetFiles(_savedPath, FileIO.SearchOption.SearchTopLevelOnly, nameNoExt & ".*")
        'ProgBar.Step = 100 \ files.Count

        'Dim doneCnt As Integer = 0

        'For Each f As String In files 'My.Computer.FileSystem.GetFiles(_savedPath, FileIO.SearchOption.SearchTopLevelOnly, nameNoExt & ".*")
        '    Dim destFileName = Combine(_backupPath, GetFileName(f))
        '    My.Computer.FileSystem.CopyFile(f, destFileName, True)
        '    doneCnt += 1
        '    ProgBar.PerformStep()
        'Next

        'ProgBar.Value = 100
        'ProgBar.Visible = False
        ''-=-=-=-=-=-=

    End Function

    ''' <summary>
    ''' move all file related to BackupGameName from backup folder to saved game folder; return number of files moved
    ''' </summary>
    ''' <param name="BackupGameName"></param>
    ''' <param name="ProgBar">reference to a progress bar control</param>
    Public Function Restore(ByVal BackupGameName As String, ByRef ProgBar As ProgressBar) As Integer
        'Dim nameNoExt As String = GetFileNameWithoutExtension(BackupGameName)
        'CopyFiles(Me._backupPath, Me._savedPath, nameNoExt)
        Return MoveCharacter(BackupGameName, Me._backupPath, Me._savedPath, ProgBar)

    End Function


    ''' <summary>
    ''' delete all files related to SavedCharacterName; return count of number of files deleted
    ''' </summary>
    ''' <param name="SavedCharacterName">name of char with or without filex extension</param>
    ''' <param name="ProgBar">optional reference to a progress bar control to show progress</param>
    ''' <returns>Number of file deleted</returns>
    Public Function DeleteSavedCharacter(ByVal SavedCharacterName As String, Optional ByVal ProgBar As ProgressBar = Nothing) As Integer
        Dim nameNoExt As String = GetFileNameWithoutExtension(SavedCharacterName)
        Return DeleteFiles(Me._savedPath, nameNoExt, ProgBar)
    End Function


    ''' <summary>
    ''' delete all files related to BackupCharacterName; return count of number of files deleted
    ''' </summary>
    ''' <param name="BackupCharacterName">name of char with or without filex extension</param>
    ''' <param name="ProgBar">optional reference to a progress bar control to show progress</param>
    ''' <returns>Number of file deleted</returns>
    Public Function DeleteBackupCharacter(ByVal BackupCharacterName As String, Optional ByVal ProgBar As ProgressBar = Nothing) As Integer
        Dim nameNoExt As String = GetFileNameWithoutExtension(BackupCharacterName)
        Return DeleteFiles(Me._backupPath, nameNoExt, ProgBar)
    End Function


    ''' <summary>
    ''' delete all bones.* files and morgue.txt
    ''' </summary>
    Public Sub ClearBones()
        With My.Computer.FileSystem
            If BonesExist() Then

                'delete morgue file
                Try : .DeleteFile(Combine(_savedPath, MOURGE_FNAME)) : Catch : End Try

                'delete all bones files
                For Each f As String In .GetFiles(_savedPath, FileIO.SearchOption.SearchTopLevelOnly, "bones.*")
                    .DeleteFile(f, FileIO.UIOption.OnlyErrorDialogs, FileIO.RecycleOption.DeletePermanently)
                Next

            End If
        End With
    End Sub


    ''' <summary>
    ''' check if any bones.* files or the morgue.txt file exist in saved game folder
    ''' </summary>
    ''' <returns></returns>
    Public Function BonesExist() As Boolean
        With My.Computer.FileSystem
            If .FileExists(Combine(_savedPath, MOURGE_FNAME)) Or .GetFiles(_savedPath, FileIO.SearchOption.SearchTopLevelOnly, "bones.*").Count > 0 Then
                Return True
            Else
                Return False
            End If
        End With
    End Function


#End Region



#Region "Private Procuedures"

    ''' <summary>
    ''' moved all files related to SavedGamename from SourcePath to DestinationPath, updating the progress bar
    ''' </summary>
    ''' <param name="SavedGameName">name of saved game with or without file extension</param>
    ''' <param name="SourcePath">folder (ending with backslash) containing file to move</param>
    ''' <param name="DestinationPath">folder (ending with backslash) where file will be moved to</param>
    ''' <param name="ProgBar">reference to progress bar control</param>
    Private Function MoveCharacter(ByVal SavedGameName As String, ByVal SourcePath As String, ByVal DestinationPath As String, ByRef ProgBar As ProgressBar) As Integer
        Dim nameNoExt As String = GetFileNameWithoutExtension(SavedGameName)

        ProgBar.Value = 0
        ProgBar.Visible = True

        Dim files As System.Collections.ObjectModel.ReadOnlyCollection(Of String) = My.Computer.FileSystem.GetFiles(SourcePath, FileIO.SearchOption.SearchTopLevelOnly, nameNoExt & ".*")
        ProgBar.Minimum = 0
        ProgBar.Maximum = files.Count

        Dim doneCnt As Integer = 0

        For Each f As String In files
            Dim destFileName = Combine(DestinationPath, GetFileName(f))
            My.Computer.FileSystem.CopyFile(f, destFileName, True)
            doneCnt += 1
            ProgBar.Increment(1)
        Next

        ProgBar.Value = doneCnt 'make sure progress bar is full when finished
        ProgBar.Visible = False

        Return doneCnt
    End Function

    Private Sub CopyFiles(ByVal SourceFolder As String, ByVal ToFolder As String, ByVal NameNoExtension As String)

        For Each f As String In My.Computer.FileSystem.GetFiles(SourceFolder, FileIO.SearchOption.SearchTopLevelOnly, NameNoExtension & ".*")
            Dim destFileName = Combine(ToFolder, GetFileName(f))
            My.Computer.FileSystem.CopyFile(f, destFileName, True)
        Next

    End Sub


    Private Function DeleteFiles(ByVal SourceFolder As String, ByVal NameNoExtension As String, Optional ByVal ProgBar As ProgressBar = Nothing) As Integer

        Dim doneCnt As Integer = 0

        If ProgBar Is Nothing Then
            For Each f As String In My.Computer.FileSystem.GetFiles(SourceFolder, FileIO.SearchOption.SearchTopLevelOnly, NameNoExtension & ".*")
                My.Computer.FileSystem.DeleteFile(f)
                doneCnt += 1
            Next
        Else
            'setup progress bar
            ProgBar.Value = 0
            ProgBar.Visible = True
            Dim files As System.Collections.ObjectModel.ReadOnlyCollection(Of String) = My.Computer.FileSystem.GetFiles(SourceFolder, FileIO.SearchOption.SearchTopLevelOnly, NameNoExtension & ".*")
            ProgBar.Minimum = 0
            ProgBar.Maximum = files.Count

            'delete each file
            For Each f As String In files
                My.Computer.FileSystem.DeleteFile(f)
                doneCnt += 1
                ProgBar.Increment(1)
            Next

            ProgBar.Visible = False

        End If

        Return doneCnt
    End Function

#End Region



End Class
