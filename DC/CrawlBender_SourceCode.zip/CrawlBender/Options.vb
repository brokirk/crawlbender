Imports System.IO.Path
Public Class GameOptions

#Region "Constants"

    ''' <summary>
    ''' default file name for game notes
    ''' </summary>
    Public Const DEFAULT_GAME_NOTES = "n0735.xls"

    ''' <summary>
    ''' File name for game instructions
    ''' </summary>
    Public Const INSTRUCT_FNAME = "crawl.txt"

    Const APP_PATH_VAR = "{APP}"

#End Region



#Region "Properties"

    ''' <summary>
    ''' location of crawl.exe (and saved game files)
    ''' </summary>
    Public Property GamePath()
        Get
            Dim path As String

            'check if settings as path
            If My.Settings.GameFolder <> "" Then
                path = My.Settings.GameFolder
            Else
                'settings doesn't have path so use app's path
                path = My.Application.Info.DirectoryPath
            End If

            'make sure path ends with \
            If Not path.EndsWith("\") Then path = path & "\"

            'check if path is valid
            If My.Computer.FileSystem.DirectoryExists(path) Then
                Return path
            Else
                MessageBox.Show("The path " & vbLf & vbLf & path & vbLf & vbLf & "was not found", "Game Path Not Found")
                Return ""
            End If

        End Get
        Set(ByVal value)
            My.Settings.GameFolder = value
            Me.Save()
        End Set
    End Property

    ''' <summary>
    ''' location for backedup files
    ''' </summary>
    ''' <remarks>
    ''' {APP} is used to indicated game path should be inserted there
    ''' </remarks>
    Public Property BackupPath() As String
        Get
            Dim backPath As String = My.Settings.BackupFolder

            'resolve app path variable {APP}
            If backPath.Contains(APP_PATH_VAR) Then backPath = backPath.Replace(APP_PATH_VAR, Me.GamePath)

            Return backPath

        End Get
        Set(ByVal path As String)
            My.Settings.BackupFolder = path
            Me.Save()
        End Set
    End Property

    ''' <summary>
    ''' location for notes files
    ''' </summary>
    ''' <remarks>
    ''' {APP} is used to indicated game path should be inserted there
    ''' </remarks>
    Public Property NotesPath() As String
        Get
            Dim path As String = My.Settings.NotesFolder

            'resolve app path variable {APP}
            If path.Contains(APP_PATH_VAR) Then path = path.Replace(APP_PATH_VAR, Me.GamePath)

            Return path
        End Get
        Set(ByVal path As String)
            My.Settings.NotesFolder = path
            Me.Save()
        End Set
    End Property

    ''' <summary>
    ''' File name of games notes
    ''' Combine(_options.NotesPath, Me._options.GameNotes)
    ''' </summary>
    Public Property GameNotes() As String
        Get
            Dim notes As String = My.Settings.GamesNotes
            If notes = "" Then
                notes = Combine(Me.NotesPath, DEFAULT_GAME_NOTES)
            End If
            Return notes
        End Get
        Set(ByVal value As String)
            My.Settings.GamesNotes = value
            Me.Save()
        End Set
    End Property

#End Region



#Region "Public Methods"

    Public Sub Save()
        My.Settings.Save()
    End Sub

#End Region

End Class
