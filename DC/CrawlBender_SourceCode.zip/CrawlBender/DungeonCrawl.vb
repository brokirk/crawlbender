Imports system.io
Public Class DungeonCrawl

#Region "private members"

    Private Const APP_TITLE As String = "Crawl 4.0.0 beta 26"

    Private appID As Integer

    Private _ExePath As String = ""
    Private _ExeName As String = ""

    ''' <summary>
    ''' fully quallified path name used to reference Crawl EXE
    ''' </summary>
    Private ReadOnly Property FullPath() As String
        Get
            Return Path.Combine(Me._ExePath, Me._ExeName)
        End Get
    End Property

#End Region


#Region "Properties"
    
#End Region



#Region "Public Methods"

    Public Sub New(ByVal ExePath As String, Optional ByVal ExeName As String = "crawl.exe")
        _ExePath = ExePath
        _ExeName = ExeName
    End Sub

    Public Function IsSetupValid(ByRef RET_Error As String) As Boolean
        If Not My.Computer.FileSystem.FileExists(Me.FullPath) Then
            RET_Error = "game path not valid"
            Return False
        Else
            Return True
        End If
    End Function

    ''' <summary>
    ''' start crawl
    ''' </summary>
    Public Sub Launch(Optional ByVal Argument As String = "")

        If Argument <> "" Then
            appID = Shell(Me.FullPath & " " & Argument, AppWinStyle.NormalFocus)
        Else
            appID = Shell(Me.FullPath, AppWinStyle.NormalFocus)
        End If


        ' Activate the new instance of crawl
        'AppActivate(appID)

    End Sub

    ''' <summary>
    ''' Load game with an existing character
    ''' </summary>
    ''' <param name="CharacterName">Name of Character (max name size is x)</param>
    ''' <remarks>
    ''' Command line options: 
    '''   -name {string}   character name
    ''' </remarks>
    Public Sub Open(ByVal CharacterName As String)
        Me.Launch("-name " & CharacterName)
    End Sub

    Public Sub Activate()
        AppActivate(APP_TITLE)
    End Sub

#End Region

    
End Class
