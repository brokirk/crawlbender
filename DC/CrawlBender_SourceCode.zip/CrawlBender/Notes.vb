Public Class CharacterNotes


#Region "Constants"

    Const SCROLLS_HDR = "[SCROLLS]"
    Const POTIONS_HDR = "[POTIONS]"
    Const RINGS_HDR = "[RINGS]"
    Const WANDS_HDR = "[WANDS]"
    Const AMULETS_HDR = "[AMULTES]"
    Const MISC_HDR = "[MISC]"

    Private Enum Categories
        Unknown
        Scrolls
        Potions
        Rings
        Wands
        Amulets
        Misc
    End Enum


#End Region



#Region "Private Members"

    Private _fullFilename As String = ""
    Private _unsavedChanges As Boolean = True

#End Region



#Region "Public Properties"

    Public Amulets As New Notes
    Public Scrolls As New Notes
    Public Potions As New Notes
    Public Rings As New Notes
    Public Wands As New Notes
    Public Misc As New Notes


    Public ReadOnly Property FullFilename() As String
        Get
            Return _fullFilename
        End Get
    End Property


    Public ReadOnly Property Filename_NoPath() As String
        Get
            Return System.IO.Path.GetFileName(Me._fullFilename)
        End Get
    End Property

#End Region



#Region "Public Methods"

    Public Sub New(ByVal FullFileName As String)
        _fullFilename = FullFileName
    End Sub

    ''' <summary>
    ''' load notes from file
    ''' </summary>
    Public Sub Load()
        ParseFileContents(My.Computer.FileSystem.ReadAllText(_fullFilename, System.Text.Encoding.ASCII))
    End Sub


    ''' <summary>
    ''' save notes to disk
    ''' </summary>
    Public Sub Save()
        My.Computer.FileSystem.WriteAllText(_fullFilename, Me.ToString, False, System.Text.Encoding.ASCII)
    End Sub


    Public Sub Create()
        Amulets = New Notes
        Scrolls = New Notes
        Potions = New Notes
        Rings = New Notes
        Wands = New Notes
        Misc = New Notes
        Me.Save()
    End Sub


    ''' <summary>
    ''' concatenate all note lists into a newline-delimited string
    ''' </summary>
    Public Overrides Function ToString() As String

        Dim fileBuilder As New System.Text.StringBuilder

        fileBuilder.AppendLine(SCROLLS_HDR)
        fileBuilder.Append(Me.Scrolls.ToString)
        fileBuilder.AppendLine()

        fileBuilder.AppendLine(POTIONS_HDR)
        fileBuilder.Append(Me.Potions.ToString)
        fileBuilder.AppendLine()

        fileBuilder.AppendLine(RINGS_HDR)
        fileBuilder.Append(Me.Rings.ToString)
        fileBuilder.AppendLine()

        fileBuilder.AppendLine(WANDS_HDR)
        fileBuilder.Append(Me.Wands.ToString)
        fileBuilder.AppendLine()

        fileBuilder.AppendLine(AMULETS_HDR)
        fileBuilder.Append(Me.Amulets.ToString)
        fileBuilder.AppendLine()

        fileBuilder.AppendLine(MISC_HDR)
        fileBuilder.Append(Me.Misc.ToString)
        fileBuilder.AppendLine()

        Return fileBuilder.ToString
    End Function

    ''' <summary>
    ''' flag if file exists
    ''' </summary>
    Public Function FileExists() As Boolean
        Return My.Computer.FileSystem.FileExists(_fullFilename)
    End Function


#End Region


#Region "Private Procedures"

    ''' <summary>
    ''' parse file content test to appropriate category tabs
    ''' </summary>
    Private Sub ParseFileContents(ByRef wholeFile As String)

        Dim parsedFile() As String = wholeFile.Split(vbCrLf)
        Dim currentCat As Categories = Categories.Unknown
        Dim ln As String

        For i As Integer = 0 To parsedFile.Length - 1

            ln = parsedFile(i).Replace(vbLf, "")

            If ln.Contains(SCROLLS_HDR) Then
                currentCat = Categories.Scrolls

            ElseIf ln.ToUpper.Contains(POTIONS_HDR) Then
                currentCat = Categories.Potions

            ElseIf ln.ToUpper.Contains(RINGS_HDR) Then
                currentCat = Categories.Rings

            ElseIf ln.ToUpper.Contains(AMULETS_HDR) Then
                currentCat = Categories.Amulets

            ElseIf ln.ToUpper.Contains(WANDS_HDR) Then
                currentCat = Categories.Wands

            ElseIf ln.ToUpper.Contains(MISC_HDR) Then
                currentCat = Categories.Misc

            ElseIf ln.Trim = "" Then
                'ingore

            ElseIf ln.Trim <> "" Then
                AddToList(ln, currentCat) 'add non blank items to approaprate category

            End If


        Next

    End Sub

    ''' <summary>
    ''' add item to approprate tab
    ''' </summary>
    ''' <param name="Item">item to add</param>
    ''' <param name="Cat">current category tab that item will be added to</param>
    Private Sub AddToList(ByVal Item As String, ByVal Cat As Categories)

        Select Case Cat
            Case Categories.Scrolls : Scrolls.AddNote(Item)
            Case Categories.Potions : Potions.AddNote(Item)
            Case Categories.Rings : Rings.AddNote(Item)
            Case Categories.Amulets : Amulets.AddNote(Item)
            Case Categories.Wands : Wands.AddNote(Item)
            Case Categories.Misc : Misc.AddNote(Item)
            Case Else
        End Select
    End Sub



#End Region


End Class



'===================================================================================
''' <summary>
''' Collections of related note objects
''' </summary>
Public Class Notes
    Inherits List(Of Note)


    ''' <summary>
    ''' Parse item string and add new note to list
    ''' </summary>
    Public Sub AddNote(ByVal ItemString As String)

        Dim nt As New Note
        ParseItemString(ItemString, nt.Title, nt.Content)
        Me.Add(nt)
        SortNotes()

    End Sub

    Public Overrides Function ToString() As String

        Dim sb As New System.Text.StringBuilder

        For Each nt As Note In Me
            sb.AppendLine(nt.ToString)
        Next

        Return sb.ToString

    End Function

    Public Sub SortNotes()
        Me.Sort(AddressOf CompareNotes)
    End Sub

    ''' <summary>
    ''' used as a Comparison generic delegate in SortNotes()
    ''' </summary>    
    Private Shared Function CompareNotes(ByVal x As Note, ByVal y As Note) As Integer

        If x Is Nothing Then

            If y Is Nothing Then
                ' If x is Nothing and y is Nothing, they're equal. 
                Return 0
            Else
                ' If x is Nothing and y is not Nothing, y is greater. 
                Return -1
            End If

        Else

            ' If x is not Nothing...
            If y Is Nothing Then
                ' ...and y is Nothing, x is greater.
                Return 1
            Else
                ' ...and y is not Nothing, compare the titles of the two notes                 
                ' sort them with ordinary string comparison.

                Return x.Title.CompareTo(y.Title)

            End If
        End If

    End Function


    ''' <summary>
    ''' parse item string into title and content; return them by reference
    ''' </summary>
    ''' <param name="ItemStr">item string in format TITLE (CONTENT)</param>
    ''' <param name="RET_title">RETURN by Ref: Title</param>
    ''' <param name="RET_content">RETURN by Ref: content</param>
    ''' <remarks>If there is not text in parentheses then content is returned empty</remarks>
    Private Sub ParseItemString(ByVal ItemStr As String, ByRef RET_title As String, ByRef RET_content As String)

        'get title
        If Not ItemStr.Contains("(") Then
            RET_title = ItemStr.Trim  'return whole string
        Else
            RET_title = ItemStr.Substring(0, ItemStr.IndexOf("(")).Trim   'return text before "("
        End If

        'get content
        If Not ItemStr.Contains("(") Then
            RET_content = ""
        Else
            Dim typeStr As String = ItemStr.Substring(ItemStr.IndexOf("(") + 1)   'get text after "("
            RET_content = typeStr.Substring(0, typeStr.Length - 1).Trim 'return everthing but closing ")"
        End If

    End Sub


End Class




'===================================================================================
''' <summary>
''' A single note row; Title (Content)
''' </summary>
''' <remarks></remarks>
Public Class Note

#Region "Properties"
    Public Title As String
    Public Content As String
#End Region



#Region "Public Methods"

    ''' <summary>
    ''' convert object into string in the format "Title (Content)"
    ''' </summary>
    Public Overrides Function ToString() As String
        If Content.Trim <> "" Then
            Return Title & " (" & Content & ")"
        Else
            Return Title
        End If
    End Function

    Public Sub New()
        Title = ""
        Content = ""
    End Sub

    Public Sub New(ByVal NewTitle As String, ByVal NewContent As String)
        Title = NewTitle
        Content = NewContent
    End Sub

#End Region

End Class





'''' <summary>
'''' build string of all items in all note categories
'''' </summary>
'''' <param name="NotesFilename">full path to note file</param>
'Private Sub SaveNotes(ByVal NotesFilename As String, Optional ByVal CreateNew As Boolean = False)
'    Dim notesBuilder As New System.Text.StringBuilder
'    Dim foundItems As Integer = 0

'    'add scrolls, potions, rings, wands, amulets
'    foundItems += BuildSaveFile(SCROLLS, notesBuilder, ScrollNotes.Items)
'    foundItems += BuildSaveFile(POTIONS, notesBuilder, PotionNotes.Items)
'    foundItems += BuildSaveFile(RINGS, notesBuilder, RingNotes.Items)
'    foundItems += BuildSaveFile(WANDS, notesBuilder, WandNotes.Items)
'    foundItems += BuildSaveFile(AMULETS, notesBuilder, AmuletNotes.Items)

'    'add misc
'    foundItems += BuildSaveFile(MISC, notesBuilder, MiscNotes.Items)


'    If foundItems > 0 Or CreateNew Then
'        'write string to file
'        My.Computer.FileSystem.WriteAllText(NotesFilename, notesBuilder.ToString, False)
'        MarkAllNotesSaved()

'    Else
'        MessageBox.Show("No notes found", "Failed to save notes")
'    End If

'End Sub
'''' <summary>
'''' loop thru items and build string
'''' </summary>
'''' <param name="Title">Title for item's section (i.e. [WANDS])</param>
'''' <param name="Sb">ref to as initialized stringbuilder</param>
'''' <param name="Items">list of strings representing items</param>
'Private Function BuildSaveFile(ByVal Title As String, ByRef Sb As System.Text.StringBuilder, ByRef Items As List(Of String)) As Integer
'    With Sb
'        .AppendLine(Title)
'        If ScrollNotes.Items.Count > 0 Then
'            For Each item As String In Items
'                .AppendLine(item)
'            Next
'            .AppendLine()
'        End If
'    End With
'    Return Items.Count
'End Function