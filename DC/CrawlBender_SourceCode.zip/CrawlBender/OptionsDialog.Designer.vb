<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class OptionsDialog
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel
        Me.OK_Button = New System.Windows.Forms.Button
        Me.Cancel_Button = New System.Windows.Forms.Button
        Me.PathsGroup = New System.Windows.Forms.GroupBox
        Me.SelectGameNotes = New System.Windows.Forms.Button
        Me.GameNotesLabel = New System.Windows.Forms.Label
        Me.GameNotesText = New System.Windows.Forms.TextBox
        Me.BackupPathButton = New System.Windows.Forms.Button
        Me.Label3 = New System.Windows.Forms.Label
        Me.BackupPathText = New System.Windows.Forms.TextBox
        Me.NotesPathButton = New System.Windows.Forms.Button
        Me.NotesPathLabel = New System.Windows.Forms.Label
        Me.NotesPathText = New System.Windows.Forms.TextBox
        Me.GamePathButton = New System.Windows.Forms.Button
        Me.GamePathLabel = New System.Windows.Forms.Label
        Me.GamePathText = New System.Windows.Forms.TextBox
        Me.FolderDialog = New System.Windows.Forms.FolderBrowserDialog
        Me.SelectFileDialog = New System.Windows.Forms.OpenFileDialog
        Me.TableLayoutPanel1.SuspendLayout()
        Me.PathsGroup.SuspendLayout()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel1.ColumnCount = 2
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.OK_Button, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Cancel_Button, 1, 0)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(423, 300)
        Me.TableLayoutPanel1.Margin = New System.Windows.Forms.Padding(4)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 1
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(195, 36)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'OK_Button
        '
        Me.OK_Button.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.OK_Button.Location = New System.Drawing.Point(4, 4)
        Me.OK_Button.Margin = New System.Windows.Forms.Padding(4)
        Me.OK_Button.Name = "OK_Button"
        Me.OK_Button.Size = New System.Drawing.Size(89, 28)
        Me.OK_Button.TabIndex = 0
        Me.OK_Button.Text = "OK"
        '
        'Cancel_Button
        '
        Me.Cancel_Button.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Cancel_Button.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Cancel_Button.Location = New System.Drawing.Point(101, 4)
        Me.Cancel_Button.Margin = New System.Windows.Forms.Padding(4)
        Me.Cancel_Button.Name = "Cancel_Button"
        Me.Cancel_Button.Size = New System.Drawing.Size(89, 28)
        Me.Cancel_Button.TabIndex = 1
        Me.Cancel_Button.Text = "Cancel"
        '
        'PathsGroup
        '
        Me.PathsGroup.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PathsGroup.Controls.Add(Me.SelectGameNotes)
        Me.PathsGroup.Controls.Add(Me.GameNotesLabel)
        Me.PathsGroup.Controls.Add(Me.GameNotesText)
        Me.PathsGroup.Controls.Add(Me.BackupPathButton)
        Me.PathsGroup.Controls.Add(Me.Label3)
        Me.PathsGroup.Controls.Add(Me.BackupPathText)
        Me.PathsGroup.Controls.Add(Me.NotesPathButton)
        Me.PathsGroup.Controls.Add(Me.NotesPathLabel)
        Me.PathsGroup.Controls.Add(Me.NotesPathText)
        Me.PathsGroup.Controls.Add(Me.GamePathButton)
        Me.PathsGroup.Controls.Add(Me.GamePathLabel)
        Me.PathsGroup.Controls.Add(Me.GamePathText)
        Me.PathsGroup.Location = New System.Drawing.Point(12, 12)
        Me.PathsGroup.Name = "PathsGroup"
        Me.PathsGroup.Size = New System.Drawing.Size(606, 236)
        Me.PathsGroup.TabIndex = 1
        Me.PathsGroup.TabStop = False
        Me.PathsGroup.Text = "Set Paths"
        '
        'SelectGameNotes
        '
        Me.SelectGameNotes.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.SelectGameNotes.Location = New System.Drawing.Point(515, 192)
        Me.SelectGameNotes.Name = "SelectGameNotes"
        Me.SelectGameNotes.Size = New System.Drawing.Size(75, 26)
        Me.SelectGameNotes.TabIndex = 11
        Me.SelectGameNotes.Text = "Select"
        Me.SelectGameNotes.UseVisualStyleBackColor = True
        '
        'GameNotesLabel
        '
        Me.GameNotesLabel.AutoSize = True
        Me.GameNotesLabel.Location = New System.Drawing.Point(6, 171)
        Me.GameNotesLabel.Name = "GameNotesLabel"
        Me.GameNotesLabel.Size = New System.Drawing.Size(154, 17)
        Me.GameNotesLabel.TabIndex = 10
        Me.GameNotesLabel.Text = "Game Notes File Name"
        '
        'GameNotesText
        '
        Me.GameNotesText.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GameNotesText.Location = New System.Drawing.Point(6, 194)
        Me.GameNotesText.Name = "GameNotesText"
        Me.GameNotesText.Size = New System.Drawing.Size(503, 22)
        Me.GameNotesText.TabIndex = 9
        '
        'BackupPathButton
        '
        Me.BackupPathButton.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.BackupPathButton.Location = New System.Drawing.Point(515, 144)
        Me.BackupPathButton.Name = "BackupPathButton"
        Me.BackupPathButton.Size = New System.Drawing.Size(75, 26)
        Me.BackupPathButton.TabIndex = 8
        Me.BackupPathButton.Text = "Select"
        Me.BackupPathButton.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(6, 123)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(88, 17)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "Backup Path"
        '
        'BackupPathText
        '
        Me.BackupPathText.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.BackupPathText.Location = New System.Drawing.Point(6, 146)
        Me.BackupPathText.Name = "BackupPathText"
        Me.BackupPathText.Size = New System.Drawing.Size(503, 22)
        Me.BackupPathText.TabIndex = 6
        '
        'NotesPathButton
        '
        Me.NotesPathButton.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.NotesPathButton.Location = New System.Drawing.Point(515, 96)
        Me.NotesPathButton.Name = "NotesPathButton"
        Me.NotesPathButton.Size = New System.Drawing.Size(75, 26)
        Me.NotesPathButton.TabIndex = 5
        Me.NotesPathButton.Text = "Select"
        Me.NotesPathButton.UseVisualStyleBackColor = True
        '
        'NotesPathLabel
        '
        Me.NotesPathLabel.AutoSize = True
        Me.NotesPathLabel.Location = New System.Drawing.Point(6, 75)
        Me.NotesPathLabel.Name = "NotesPathLabel"
        Me.NotesPathLabel.Size = New System.Drawing.Size(78, 17)
        Me.NotesPathLabel.TabIndex = 4
        Me.NotesPathLabel.Text = "Notes Path"
        '
        'NotesPathText
        '
        Me.NotesPathText.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.NotesPathText.Location = New System.Drawing.Point(6, 98)
        Me.NotesPathText.Name = "NotesPathText"
        Me.NotesPathText.Size = New System.Drawing.Size(503, 22)
        Me.NotesPathText.TabIndex = 3
        '
        'GamePathButton
        '
        Me.GamePathButton.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.GamePathButton.Location = New System.Drawing.Point(515, 48)
        Me.GamePathButton.Name = "GamePathButton"
        Me.GamePathButton.Size = New System.Drawing.Size(75, 26)
        Me.GamePathButton.TabIndex = 2
        Me.GamePathButton.Text = "Select"
        Me.GamePathButton.UseVisualStyleBackColor = True
        '
        'GamePathLabel
        '
        Me.GamePathLabel.AutoSize = True
        Me.GamePathLabel.Location = New System.Drawing.Point(6, 27)
        Me.GamePathLabel.Name = "GamePathLabel"
        Me.GamePathLabel.Size = New System.Drawing.Size(79, 17)
        Me.GamePathLabel.TabIndex = 1
        Me.GamePathLabel.Text = "Game Path"
        '
        'GamePathText
        '
        Me.GamePathText.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GamePathText.Location = New System.Drawing.Point(6, 50)
        Me.GamePathText.Name = "GamePathText"
        Me.GamePathText.Size = New System.Drawing.Size(503, 22)
        Me.GamePathText.TabIndex = 0
        '
        'SelectFileDialog
        '
        Me.SelectFileDialog.FileName = "OpenFileDialog1"
        '
        'OptionsDialog
        '
        Me.AcceptButton = Me.OK_Button
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.Cancel_Button
        Me.ClientSize = New System.Drawing.Size(634, 351)
        Me.Controls.Add(Me.PathsGroup)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "OptionsDialog"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Options"
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.PathsGroup.ResumeLayout(False)
        Me.PathsGroup.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents OK_Button As System.Windows.Forms.Button
    Friend WithEvents Cancel_Button As System.Windows.Forms.Button
    Friend WithEvents PathsGroup As System.Windows.Forms.GroupBox
    Friend WithEvents NotesPathButton As System.Windows.Forms.Button
    Friend WithEvents NotesPathLabel As System.Windows.Forms.Label
    Friend WithEvents NotesPathText As System.Windows.Forms.TextBox
    Friend WithEvents GamePathButton As System.Windows.Forms.Button
    Friend WithEvents GamePathLabel As System.Windows.Forms.Label
    Friend WithEvents GamePathText As System.Windows.Forms.TextBox
    Friend WithEvents SelectGameNotes As System.Windows.Forms.Button
    Friend WithEvents GameNotesLabel As System.Windows.Forms.Label
    Friend WithEvents GameNotesText As System.Windows.Forms.TextBox
    Friend WithEvents BackupPathButton As System.Windows.Forms.Button
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents BackupPathText As System.Windows.Forms.TextBox
    Friend WithEvents FolderDialog As System.Windows.Forms.FolderBrowserDialog
    Friend WithEvents SelectFileDialog As System.Windows.Forms.OpenFileDialog

End Class
