<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CrystalBall
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ListBox1 = New System.Windows.Forms.ListBox
        Me.ListBox2 = New System.Windows.Forms.ListBox
        Me.Load1Button = New System.Windows.Forms.Button
        Me.Load2Button = New System.Windows.Forms.Button
        Me.CompareButton = New System.Windows.Forms.Button
        Me.CompareList = New System.Windows.Forms.ListBox
        Me.GamePathLabel = New System.Windows.Forms.Label
        Me.NextButton = New System.Windows.Forms.Button
        Me.PrevButton = New System.Windows.Forms.Button
        Me.CurrentPosText = New System.Windows.Forms.TextBox
        Me.TotalMatchesLabel = New System.Windows.Forms.Label
        Me.GoToButton = New System.Windows.Forms.Button
        Me.NavGroupBox = New System.Windows.Forms.GroupBox
        Me.SavedList = New System.Windows.Forms.ListBox
        Me.SaveCompareButton = New System.Windows.Forms.Button
        Me.FindGroupBox = New System.Windows.Forms.GroupBox
        Me.FindNextButton = New System.Windows.Forms.Button
        Me.FindButton = New System.Windows.Forms.Button
        Me.FindText = New System.Windows.Forms.TextBox
        Me.ByteValue = New System.Windows.Forms.TextBox
        Me.ByteNum = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.ChangeBytesGroup = New System.Windows.Forms.GroupBox
        Me.SaveButton = New System.Windows.Forms.Button
        Me.GetValueButton = New System.Windows.Forms.Button
        Me.NavGroupBox.SuspendLayout()
        Me.FindGroupBox.SuspendLayout()
        Me.ChangeBytesGroup.SuspendLayout()
        Me.SuspendLayout()
        '
        'ListBox1
        '
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.ItemHeight = 16
        Me.ListBox1.Location = New System.Drawing.Point(12, 44)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(150, 308)
        Me.ListBox1.TabIndex = 0
        '
        'ListBox2
        '
        Me.ListBox2.FormattingEnabled = True
        Me.ListBox2.ItemHeight = 16
        Me.ListBox2.Location = New System.Drawing.Point(168, 44)
        Me.ListBox2.Name = "ListBox2"
        Me.ListBox2.Size = New System.Drawing.Size(150, 308)
        Me.ListBox2.TabIndex = 1
        '
        'Load1Button
        '
        Me.Load1Button.Location = New System.Drawing.Point(48, 12)
        Me.Load1Button.Name = "Load1Button"
        Me.Load1Button.Size = New System.Drawing.Size(75, 26)
        Me.Load1Button.TabIndex = 2
        Me.Load1Button.Text = "Load 1"
        Me.Load1Button.UseVisualStyleBackColor = True
        '
        'Load2Button
        '
        Me.Load2Button.Location = New System.Drawing.Point(208, 12)
        Me.Load2Button.Name = "Load2Button"
        Me.Load2Button.Size = New System.Drawing.Size(75, 26)
        Me.Load2Button.TabIndex = 3
        Me.Load2Button.Text = "Load 2"
        Me.Load2Button.UseVisualStyleBackColor = True
        '
        'CompareButton
        '
        Me.CompareButton.Location = New System.Drawing.Point(362, 12)
        Me.CompareButton.Name = "CompareButton"
        Me.CompareButton.Size = New System.Drawing.Size(75, 26)
        Me.CompareButton.TabIndex = 4
        Me.CompareButton.Text = "Compare"
        Me.CompareButton.UseVisualStyleBackColor = True
        '
        'CompareList
        '
        Me.CompareList.FormattingEnabled = True
        Me.CompareList.ItemHeight = 16
        Me.CompareList.Location = New System.Drawing.Point(324, 44)
        Me.CompareList.Name = "CompareList"
        Me.CompareList.Size = New System.Drawing.Size(150, 308)
        Me.CompareList.TabIndex = 5
        '
        'GamePathLabel
        '
        Me.GamePathLabel.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.GamePathLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.GamePathLabel.Location = New System.Drawing.Point(12, 455)
        Me.GamePathLabel.Name = "GamePathLabel"
        Me.GamePathLabel.Size = New System.Drawing.Size(644, 37)
        Me.GamePathLabel.TabIndex = 6
        Me.GamePathLabel.Text = "Game Path"
        '
        'NextButton
        '
        Me.NextButton.Location = New System.Drawing.Point(87, 21)
        Me.NextButton.Name = "NextButton"
        Me.NextButton.Size = New System.Drawing.Size(75, 29)
        Me.NextButton.TabIndex = 7
        Me.NextButton.Text = "Next"
        Me.NextButton.UseVisualStyleBackColor = True
        '
        'PrevButton
        '
        Me.PrevButton.Location = New System.Drawing.Point(6, 21)
        Me.PrevButton.Name = "PrevButton"
        Me.PrevButton.Size = New System.Drawing.Size(75, 28)
        Me.PrevButton.TabIndex = 8
        Me.PrevButton.Text = "Prev"
        Me.PrevButton.UseVisualStyleBackColor = True
        '
        'CurrentPosText
        '
        Me.CurrentPosText.Location = New System.Drawing.Point(6, 59)
        Me.CurrentPosText.Name = "CurrentPosText"
        Me.CurrentPosText.Size = New System.Drawing.Size(75, 22)
        Me.CurrentPosText.TabIndex = 9
        Me.CurrentPosText.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TotalMatchesLabel
        '
        Me.TotalMatchesLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TotalMatchesLabel.Location = New System.Drawing.Point(6, 97)
        Me.TotalMatchesLabel.Name = "TotalMatchesLabel"
        Me.TotalMatchesLabel.Size = New System.Drawing.Size(156, 23)
        Me.TotalMatchesLabel.TabIndex = 10
        Me.TotalMatchesLabel.Text = "Total Matches"
        Me.TotalMatchesLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'GoToButton
        '
        Me.GoToButton.Location = New System.Drawing.Point(87, 56)
        Me.GoToButton.Name = "GoToButton"
        Me.GoToButton.Size = New System.Drawing.Size(75, 29)
        Me.GoToButton.TabIndex = 11
        Me.GoToButton.Text = "GOTO"
        Me.GoToButton.UseVisualStyleBackColor = True
        '
        'NavGroupBox
        '
        Me.NavGroupBox.Controls.Add(Me.NextButton)
        Me.NavGroupBox.Controls.Add(Me.GoToButton)
        Me.NavGroupBox.Controls.Add(Me.PrevButton)
        Me.NavGroupBox.Controls.Add(Me.TotalMatchesLabel)
        Me.NavGroupBox.Controls.Add(Me.CurrentPosText)
        Me.NavGroupBox.Location = New System.Drawing.Point(480, 12)
        Me.NavGroupBox.Name = "NavGroupBox"
        Me.NavGroupBox.Size = New System.Drawing.Size(169, 133)
        Me.NavGroupBox.TabIndex = 12
        Me.NavGroupBox.TabStop = False
        '
        'SavedList
        '
        Me.SavedList.FormattingEnabled = True
        Me.SavedList.ItemHeight = 16
        Me.SavedList.Location = New System.Drawing.Point(486, 217)
        Me.SavedList.Name = "SavedList"
        Me.SavedList.Size = New System.Drawing.Size(170, 228)
        Me.SavedList.TabIndex = 13
        '
        'SaveCompareButton
        '
        Me.SaveCompareButton.Location = New System.Drawing.Point(516, 185)
        Me.SaveCompareButton.Name = "SaveCompareButton"
        Me.SaveCompareButton.Size = New System.Drawing.Size(96, 26)
        Me.SaveCompareButton.TabIndex = 14
        Me.SaveCompareButton.Text = "Save"
        Me.SaveCompareButton.UseVisualStyleBackColor = True
        '
        'FindGroupBox
        '
        Me.FindGroupBox.Controls.Add(Me.FindNextButton)
        Me.FindGroupBox.Controls.Add(Me.FindButton)
        Me.FindGroupBox.Controls.Add(Me.FindText)
        Me.FindGroupBox.Enabled = False
        Me.FindGroupBox.Location = New System.Drawing.Point(12, 358)
        Me.FindGroupBox.Name = "FindGroupBox"
        Me.FindGroupBox.Size = New System.Drawing.Size(223, 87)
        Me.FindGroupBox.TabIndex = 15
        Me.FindGroupBox.TabStop = False
        Me.FindGroupBox.Text = "Find"
        '
        'FindNextButton
        '
        Me.FindNextButton.Location = New System.Drawing.Point(116, 53)
        Me.FindNextButton.Name = "FindNextButton"
        Me.FindNextButton.Size = New System.Drawing.Size(96, 29)
        Me.FindNextButton.TabIndex = 13
        Me.FindNextButton.Text = "Find Next"
        Me.FindNextButton.UseVisualStyleBackColor = True
        '
        'FindButton
        '
        Me.FindButton.Location = New System.Drawing.Point(116, 18)
        Me.FindButton.Name = "FindButton"
        Me.FindButton.Size = New System.Drawing.Size(96, 29)
        Me.FindButton.TabIndex = 12
        Me.FindButton.Text = "Find"
        Me.FindButton.UseVisualStyleBackColor = True
        '
        'FindText
        '
        Me.FindText.Location = New System.Drawing.Point(6, 21)
        Me.FindText.Name = "FindText"
        Me.FindText.Size = New System.Drawing.Size(105, 22)
        Me.FindText.TabIndex = 10
        Me.FindText.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'ByteValue
        '
        Me.ByteValue.Location = New System.Drawing.Point(56, 56)
        Me.ByteValue.Name = "ByteValue"
        Me.ByteValue.Size = New System.Drawing.Size(75, 22)
        Me.ByteValue.TabIndex = 14
        Me.ByteValue.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'ByteNum
        '
        Me.ByteNum.Location = New System.Drawing.Point(56, 25)
        Me.ByteNum.Name = "ByteNum"
        Me.ByteNum.Size = New System.Drawing.Size(75, 22)
        Me.ByteNum.TabIndex = 15
        Me.ByteNum.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(6, 28)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(48, 17)
        Me.Label1.TabIndex = 16
        Me.Label1.Text = "Byte #"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(6, 56)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(44, 17)
        Me.Label2.TabIndex = 17
        Me.Label2.Text = "Value"
        '
        'ChangeBytesGroup
        '
        Me.ChangeBytesGroup.Controls.Add(Me.SaveButton)
        Me.ChangeBytesGroup.Controls.Add(Me.GetValueButton)
        Me.ChangeBytesGroup.Controls.Add(Me.ByteNum)
        Me.ChangeBytesGroup.Controls.Add(Me.Label2)
        Me.ChangeBytesGroup.Controls.Add(Me.Label1)
        Me.ChangeBytesGroup.Controls.Add(Me.ByteValue)
        Me.ChangeBytesGroup.Enabled = False
        Me.ChangeBytesGroup.Location = New System.Drawing.Point(241, 358)
        Me.ChangeBytesGroup.Name = "ChangeBytesGroup"
        Me.ChangeBytesGroup.Size = New System.Drawing.Size(239, 87)
        Me.ChangeBytesGroup.TabIndex = 18
        Me.ChangeBytesGroup.TabStop = False
        Me.ChangeBytesGroup.Text = "Change Bytes"
        '
        'SaveButton
        '
        Me.SaveButton.Location = New System.Drawing.Point(151, 50)
        Me.SaveButton.Name = "SaveButton"
        Me.SaveButton.Size = New System.Drawing.Size(82, 29)
        Me.SaveButton.TabIndex = 19
        Me.SaveButton.Text = "Save File"
        Me.SaveButton.UseVisualStyleBackColor = True
        '
        'GetValueButton
        '
        Me.GetValueButton.Location = New System.Drawing.Point(151, 18)
        Me.GetValueButton.Name = "GetValueButton"
        Me.GetValueButton.Size = New System.Drawing.Size(82, 29)
        Me.GetValueButton.TabIndex = 18
        Me.GetValueButton.Text = "Get Value"
        Me.GetValueButton.UseVisualStyleBackColor = True
        '
        'CrystalBall
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(668, 501)
        Me.Controls.Add(Me.ChangeBytesGroup)
        Me.Controls.Add(Me.FindGroupBox)
        Me.Controls.Add(Me.SaveCompareButton)
        Me.Controls.Add(Me.SavedList)
        Me.Controls.Add(Me.NavGroupBox)
        Me.Controls.Add(Me.GamePathLabel)
        Me.Controls.Add(Me.CompareList)
        Me.Controls.Add(Me.CompareButton)
        Me.Controls.Add(Me.Load2Button)
        Me.Controls.Add(Me.Load1Button)
        Me.Controls.Add(Me.ListBox2)
        Me.Controls.Add(Me.ListBox1)
        Me.Name = "CrystalBall"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "CrystalBall"
        Me.NavGroupBox.ResumeLayout(False)
        Me.NavGroupBox.PerformLayout()
        Me.FindGroupBox.ResumeLayout(False)
        Me.FindGroupBox.PerformLayout()
        Me.ChangeBytesGroup.ResumeLayout(False)
        Me.ChangeBytesGroup.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox2 As System.Windows.Forms.ListBox
    Friend WithEvents Load1Button As System.Windows.Forms.Button
    Friend WithEvents Load2Button As System.Windows.Forms.Button
    Friend WithEvents CompareButton As System.Windows.Forms.Button
    Friend WithEvents CompareList As System.Windows.Forms.ListBox
    Friend WithEvents GamePathLabel As System.Windows.Forms.Label
    Friend WithEvents NextButton As System.Windows.Forms.Button
    Friend WithEvents PrevButton As System.Windows.Forms.Button
    Friend WithEvents CurrentPosText As System.Windows.Forms.TextBox
    Friend WithEvents TotalMatchesLabel As System.Windows.Forms.Label
    Friend WithEvents GoToButton As System.Windows.Forms.Button
    Friend WithEvents NavGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents SavedList As System.Windows.Forms.ListBox
    Friend WithEvents SaveCompareButton As System.Windows.Forms.Button
    Friend WithEvents FindGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents FindButton As System.Windows.Forms.Button
    Friend WithEvents FindText As System.Windows.Forms.TextBox
    Friend WithEvents FindNextButton As System.Windows.Forms.Button
    Friend WithEvents ChangeBytesGroup As System.Windows.Forms.GroupBox
    Friend WithEvents ByteNum As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents ByteValue As System.Windows.Forms.TextBox
    Friend WithEvents SaveButton As System.Windows.Forms.Button
    Friend WithEvents GetValueButton As System.Windows.Forms.Button
End Class
