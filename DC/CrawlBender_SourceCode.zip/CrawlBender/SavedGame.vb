Public Class SavedGameFile

#Region "Constants"

    ' these base values are added to length of character's name to get the actual position of the value in the file
    Const HP_POS_BASE = 36 ' 41 = 36 + len("HeMan") = 36 + 5
    Const MP_POS_BASE = 54 ' 59 = 54 + len("HeMan")
    Const FOOD_POS1_BASE = 41   ' 46
    Const FOOD_POS2_BASE = 42   ' 47
    Const GOLD_POS_BASE = 71   ' 77     'gold is (at least) a two byte number; pos 71 is the 256^1 place while 72 is the 256^0 place.


    '?? Fast Position 37 + charName.Length set to 255 ???
#End Region



#Region "Private Members"
    Private _filename As String
    Public _fileContents As Byte()
#End Region



#Region "Properties"

    Private _characterName As String = ""
    ''' <summary>
    ''' Character's name (as contained in saved file, NOT the saved file name)
    ''' </summary>
    Private ReadOnly Property CharacterName() As String
        Get
            If _characterName = "" Then
                _characterName = GetCharacterName()
            End If
            Return _characterName
        End Get
    End Property

    ''' <summary>
    ''' position in file of the HP value
    ''' </summary>
    Private ReadOnly Property HP_Position() As Integer
        Get
            Return HP_POS_BASE + Me.CharacterName.Length
        End Get
    End Property

    Private ReadOnly Property MP_Position() As Integer
        Get
            Return MP_POS_BASE + Me.CharacterName.Length
        End Get
    End Property

    Private ReadOnly Property Food_Position() As Integer
        Get
            Return FOOD_POS1_BASE + Me.CharacterName.Length
        End Get
    End Property

    Private ReadOnly Property Gold_Position() As Integer
        Get
            Return GOLD_POS_BASE + Me.CharacterName.Length
        End Get
    End Property

#End Region



#Region "Public Methods"

    ''' <summary>
    ''' Constructor
    ''' </summary>
    ''' <param name="SaveFilename">full file name (including path) of saved game file</param>
    ''' <remarks></remarks>
    Public Sub New(ByVal SaveFilename As String)
        Me._filename = SaveFilename
        ReadFile()
    End Sub

    Public Sub MaxHP()
        'fileContents(HP_POS_BASE) = 255
        _fileContents(Me.HP_Position) = 255
    End Sub

    Public Sub MaxMP()
        'fileContents(MP_POS_BASE) = 100
        _fileContents(Me.MP_Position) = 100
    End Sub

    ''' <summary>
    ''' set hunger level to "Full"
    ''' </summary>
    ''' <remarks>hunder level is contained in type bypes
    ''' Values of 40 and 148 in these two bytes respectively yeilds acceptable result (not exact) </remarks>
    Public Sub FixFood()
        _fileContents(Me.Food_Position) = 40
        _fileContents(Me.Food_Position + 1) = 148
    End Sub

    ''' <summary>
    ''' give huge pile of gold
    ''' </summary>
    ''' <remarks>gold amount is contained in two bytes
    ''' 50 and 255 in these bytes yield 13055 gold pieces</remarks>
    Public Sub MaxGold()
        _fileContents(Me.Gold_Position) = 40
        _fileContents(Me.Gold_Position + 1) = 0
    End Sub

    Public Sub Save()
        Save2File()
    End Sub

#End Region


#Region "Private Procedures"

    ''' <summary>
    ''' read and save file contents
    ''' </summary>
    Sub ReadFile()
        If My.Computer.FileSystem.FileExists(_filename) Then
            _fileContents = My.Computer.FileSystem.ReadAllBytes(_filename) '("C:\Test.txt")
        Else
            Throw New Exception("Unable to find saved file '" & _filename & "' during SavedGame.ReadFile()")
        End If
    End Sub


    ''' <summary>
    ''' write fileContents stored in memory to file
    ''' </summary>
    Sub Save2File()

        'Dim fileContents() As Byte = {244, 123, 56, 34}
        My.Computer.FileSystem.WriteAllBytes(_filename, _fileContents, False)

    End Sub


    ''' <summary>
    ''' get character name from fileConetns
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks>file names are limited to 6 characters (of character's name), but Crawl store whole character name even if longer than 6</remarks>
    Private Function GetCharacterName()
        Const NAME_START_AT = 10

        Dim nm As New System.Text.StringBuilder

        Dim c As Byte
        Dim i As Integer = 0
        Do
            c = _fileContents(NAME_START_AT + i)

            'check if at null after character name has been reached
            If Not IsNormalChar(c) Then
                Exit Do
            Else
                nm.Append(Chr(c))
            End If

            i += 1   'inc to next byte

            'emergency exit, to avoid infinite loop
            If i > 100 Then
                MessageBox.Show("big problem when parsing character's name from file, check SavedGame.GetCharacterName()", "Oh No!", MessageBoxButtons.OK)
                Exit Do
            End If
        Loop

        Return nm.ToString
        'Return System.IO.Path.GetFileNameWithoutExtension(Me._filename)
    End Function


    ''' <summary>
    ''' check if byte is for a char that could be in a character's name
    ''' </summary>
    ''' <param name="c">byte number</param>
    Private Function IsNormalChar(ByVal c As Byte) As Boolean

        If c >= Asc("0") And c <= Asc("9") Then '0..9
            Return True

        ElseIf c >= Asc("A") And c <= Asc("Z") Then 'A..Z
            Return True

        ElseIf c >= Asc("a") And c <= Asc("z") Then 'a..z
            Return True

        ElseIf c = Asc("_") Or c = Asc(" ") Then
            Return True

        ElseIf c <= 31 Or c > 127 Then
            Return False

        Else
            Return False

        End If

    End Function


#End Region




End Class
