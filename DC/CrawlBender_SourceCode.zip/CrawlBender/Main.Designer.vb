<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MainForm))
        Me.MainMenu = New System.Windows.Forms.MenuStrip
        Me.FileMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.NewCharacterMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.LaunchCrawlMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator
        Me.MoveCharacterMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.DeleteCharacterMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator
        Me.ClearBonesMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator
        Me.OpenSavedFolderMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator7 = New System.Windows.Forms.ToolStripSeparator
        Me.ExitMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolsMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.OptionsMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CrystalBallMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator
        Me.ScriptSetupMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator6 = New System.Windows.Forms.ToolStripSeparator
        Me.KillCrawlsMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CommandLineMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.NotesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.OpenNotesMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ManageNotesMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator
        Me.OpenInNotepadMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.BenderMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.FixHPMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.FixBothHPMPMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.FixGoldMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.FixFoodMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.FixAllLaunchMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.FixAllBackupMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CrawlInstructMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.GameNotesMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.InstructionsExplorerMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.RefreshButton = New System.Windows.Forms.Button
        Me.SavedList = New System.Windows.Forms.ListBox
        Me.SavedGroupBox = New System.Windows.Forms.GroupBox
        Me.BackupGroupBox = New System.Windows.Forms.GroupBox
        Me.BackupList = New System.Windows.Forms.ListBox
        Me.MoveButton = New System.Windows.Forms.Button
        Me.LoadButton = New System.Windows.Forms.Button
        Me.FileProgress = New System.Windows.Forms.ProgressBar
        Me.StatusBar = New System.Windows.Forms.StatusStrip
        Me.StatusText = New System.Windows.Forms.ToolStripStatusLabel
        Me.StatusTimer = New System.Windows.Forms.Timer(Me.components)
        Me.ScriptButton = New System.Windows.Forms.Button
        Me.CmdLineText = New System.Windows.Forms.TextBox
        Me.CmdLineGroup = New System.Windows.Forms.GroupBox
        Me.CmdLineButton = New System.Windows.Forms.Button
        Me.myToolTip = New System.Windows.Forms.ToolTip(Me.components)
        Me.KillButton = New System.Windows.Forms.Button
        Me.MainMenu.SuspendLayout()
        Me.SavedGroupBox.SuspendLayout()
        Me.BackupGroupBox.SuspendLayout()
        Me.StatusBar.SuspendLayout()
        Me.CmdLineGroup.SuspendLayout()
        Me.SuspendLayout()
        '
        'MainMenu
        '
        Me.MainMenu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.MainMenu.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileMenuItem, Me.ToolsMenuItem, Me.NotesToolStripMenuItem, Me.BenderMenuItem, Me.HelpToolStripMenuItem})
        Me.MainMenu.Location = New System.Drawing.Point(0, 0)
        Me.MainMenu.Name = "MainMenu"
        Me.MainMenu.Padding = New System.Windows.Forms.Padding(4, 2, 0, 2)
        Me.MainMenu.RenderMode = System.Windows.Forms.ToolStripRenderMode.System
        Me.MainMenu.Size = New System.Drawing.Size(284, 24)
        Me.MainMenu.TabIndex = 0
        Me.MainMenu.Text = "MainMenuStrip"
        '
        'FileMenuItem
        '
        Me.FileMenuItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.FileMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewCharacterMenuItem, Me.LaunchCrawlMenuItem, Me.ToolStripSeparator1, Me.MoveCharacterMenuItem, Me.DeleteCharacterMenuItem, Me.ToolStripSeparator2, Me.ClearBonesMenuItem, Me.ToolStripSeparator4, Me.OpenSavedFolderMenuItem, Me.ToolStripSeparator7, Me.ExitMenuItem})
        Me.FileMenuItem.Name = "FileMenuItem"
        Me.FileMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileMenuItem.Text = "File"
        Me.FileMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        '
        'NewCharacterMenuItem
        '
        Me.NewCharacterMenuItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.NewCharacterMenuItem.Name = "NewCharacterMenuItem"
        Me.NewCharacterMenuItem.Size = New System.Drawing.Size(208, 22)
        Me.NewCharacterMenuItem.Text = "New Character"
        '
        'LaunchCrawlMenuItem
        '
        Me.LaunchCrawlMenuItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.LaunchCrawlMenuItem.Name = "LaunchCrawlMenuItem"
        Me.LaunchCrawlMenuItem.Size = New System.Drawing.Size(208, 22)
        Me.LaunchCrawlMenuItem.Text = "Load Saved Game"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(205, 6)
        '
        'MoveCharacterMenuItem
        '
        Me.MoveCharacterMenuItem.Name = "MoveCharacterMenuItem"
        Me.MoveCharacterMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.B), System.Windows.Forms.Keys)
        Me.MoveCharacterMenuItem.Size = New System.Drawing.Size(208, 22)
        Me.MoveCharacterMenuItem.Text = "Backup Character"
        '
        'DeleteCharacterMenuItem
        '
        Me.DeleteCharacterMenuItem.Name = "DeleteCharacterMenuItem"
        Me.DeleteCharacterMenuItem.Size = New System.Drawing.Size(208, 22)
        Me.DeleteCharacterMenuItem.Text = "Delete Character"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(205, 6)
        '
        'ClearBonesMenuItem
        '
        Me.ClearBonesMenuItem.Name = "ClearBonesMenuItem"
        Me.ClearBonesMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.C), System.Windows.Forms.Keys)
        Me.ClearBonesMenuItem.Size = New System.Drawing.Size(208, 22)
        Me.ClearBonesMenuItem.Text = "Clear Bones"
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(205, 6)
        '
        'OpenSavedFolderMenuItem
        '
        Me.OpenSavedFolderMenuItem.Name = "OpenSavedFolderMenuItem"
        Me.OpenSavedFolderMenuItem.Size = New System.Drawing.Size(208, 22)
        Me.OpenSavedFolderMenuItem.Text = "Open Saved Folder"
        '
        'ToolStripSeparator7
        '
        Me.ToolStripSeparator7.Name = "ToolStripSeparator7"
        Me.ToolStripSeparator7.Size = New System.Drawing.Size(205, 6)
        '
        'ExitMenuItem
        '
        Me.ExitMenuItem.Name = "ExitMenuItem"
        Me.ExitMenuItem.Size = New System.Drawing.Size(208, 22)
        Me.ExitMenuItem.Text = "Exit"
        '
        'ToolsMenuItem
        '
        Me.ToolsMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ToolsMenuItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.ToolsMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.OptionsMenuItem, Me.CrystalBallMenuItem, Me.ToolStripSeparator5, Me.ScriptSetupMenuItem, Me.ToolStripSeparator6, Me.KillCrawlsMenuItem, Me.CommandLineMenuItem})
        Me.ToolsMenuItem.Name = "ToolsMenuItem"
        Me.ToolsMenuItem.Size = New System.Drawing.Size(48, 20)
        Me.ToolsMenuItem.Text = "Tools"
        '
        'OptionsMenuItem
        '
        Me.OptionsMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.OptionsMenuItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.OptionsMenuItem.Name = "OptionsMenuItem"
        Me.OptionsMenuItem.Size = New System.Drawing.Size(196, 22)
        Me.OptionsMenuItem.Text = "Options"
        '
        'CrystalBallMenuItem
        '
        Me.CrystalBallMenuItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.CrystalBallMenuItem.Name = "CrystalBallMenuItem"
        Me.CrystalBallMenuItem.Size = New System.Drawing.Size(196, 22)
        Me.CrystalBallMenuItem.Text = "Crystal Ball"
        '
        'ToolStripSeparator5
        '
        Me.ToolStripSeparator5.Name = "ToolStripSeparator5"
        Me.ToolStripSeparator5.Size = New System.Drawing.Size(193, 6)
        '
        'ScriptSetupMenuItem
        '
        Me.ScriptSetupMenuItem.Name = "ScriptSetupMenuItem"
        Me.ScriptSetupMenuItem.Size = New System.Drawing.Size(196, 22)
        Me.ScriptSetupMenuItem.Text = "Script Setup"
        '
        'ToolStripSeparator6
        '
        Me.ToolStripSeparator6.Name = "ToolStripSeparator6"
        Me.ToolStripSeparator6.Size = New System.Drawing.Size(193, 6)
        '
        'KillCrawlsMenuItem
        '
        Me.KillCrawlsMenuItem.Name = "KillCrawlsMenuItem"
        Me.KillCrawlsMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.K), System.Windows.Forms.Keys)
        Me.KillCrawlsMenuItem.Size = New System.Drawing.Size(196, 22)
        Me.KillCrawlsMenuItem.Text = "Kill all Crawls"
        '
        'CommandLineMenuItem
        '
        Me.CommandLineMenuItem.Name = "CommandLineMenuItem"
        Me.CommandLineMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.L), System.Windows.Forms.Keys)
        Me.CommandLineMenuItem.Size = New System.Drawing.Size(196, 22)
        Me.CommandLineMenuItem.Text = "Command Line"
        '
        'NotesToolStripMenuItem
        '
        Me.NotesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.OpenNotesMenuItem, Me.ManageNotesMenuItem, Me.ToolStripSeparator3, Me.OpenInNotepadMenuItem})
        Me.NotesToolStripMenuItem.Name = "NotesToolStripMenuItem"
        Me.NotesToolStripMenuItem.Size = New System.Drawing.Size(50, 20)
        Me.NotesToolStripMenuItem.Text = "Notes"
        Me.NotesToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'OpenNotesMenuItem
        '
        Me.OpenNotesMenuItem.Name = "OpenNotesMenuItem"
        Me.OpenNotesMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.N), System.Windows.Forms.Keys)
        Me.OpenNotesMenuItem.Size = New System.Drawing.Size(199, 22)
        Me.OpenNotesMenuItem.Text = "Open Notes"
        '
        'ManageNotesMenuItem
        '
        Me.ManageNotesMenuItem.Name = "ManageNotesMenuItem"
        Me.ManageNotesMenuItem.Size = New System.Drawing.Size(199, 22)
        Me.ManageNotesMenuItem.Text = "Manage Notes"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(196, 6)
        '
        'OpenInNotepadMenuItem
        '
        Me.OpenInNotepadMenuItem.Name = "OpenInNotepadMenuItem"
        Me.OpenInNotepadMenuItem.Size = New System.Drawing.Size(199, 22)
        Me.OpenInNotepadMenuItem.Text = "Open Notes in Notepad"
        '
        'BenderMenuItem
        '
        Me.BenderMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FixHPMenuItem, Me.FixBothHPMPMenuItem, Me.FixGoldMenuItem, Me.FixFoodMenuItem, Me.FixAllLaunchMenuItem, Me.FixAllBackupMenuItem})
        Me.BenderMenuItem.Name = "BenderMenuItem"
        Me.BenderMenuItem.Size = New System.Drawing.Size(27, 20)
        Me.BenderMenuItem.Text = "[]"
        '
        'FixHPMenuItem
        '
        Me.FixHPMenuItem.Name = "FixHPMenuItem"
        Me.FixHPMenuItem.Size = New System.Drawing.Size(247, 22)
        Me.FixHPMenuItem.Text = "Fix HP"
        '
        'FixBothHPMPMenuItem
        '
        Me.FixBothHPMPMenuItem.Name = "FixBothHPMPMenuItem"
        Me.FixBothHPMPMenuItem.Size = New System.Drawing.Size(247, 22)
        Me.FixBothHPMPMenuItem.Text = "Fix Both HP && MP"
        '
        'FixGoldMenuItem
        '
        Me.FixGoldMenuItem.Name = "FixGoldMenuItem"
        Me.FixGoldMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.G), System.Windows.Forms.Keys)
        Me.FixGoldMenuItem.Size = New System.Drawing.Size(247, 22)
        Me.FixGoldMenuItem.Text = "Fix Gold"
        '
        'FixFoodMenuItem
        '
        Me.FixFoodMenuItem.Name = "FixFoodMenuItem"
        Me.FixFoodMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.F), System.Windows.Forms.Keys)
        Me.FixFoodMenuItem.Size = New System.Drawing.Size(247, 22)
        Me.FixFoodMenuItem.Text = "Fix Food"
        '
        'FixAllLaunchMenuItem
        '
        Me.FixAllLaunchMenuItem.Name = "FixAllLaunchMenuItem"
        Me.FixAllLaunchMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Z), System.Windows.Forms.Keys)
        Me.FixAllLaunchMenuItem.Size = New System.Drawing.Size(247, 22)
        Me.FixAllLaunchMenuItem.Text = "Fix All && Launch"
        '
        'FixAllBackupMenuItem
        '
        Me.FixAllBackupMenuItem.Name = "FixAllBackupMenuItem"
        Me.FixAllBackupMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.A), System.Windows.Forms.Keys)
        Me.FixAllBackupMenuItem.Size = New System.Drawing.Size(247, 22)
        Me.FixAllBackupMenuItem.Text = "Fix All, Backup && Launch"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CrawlInstructMenuItem, Me.GameNotesMenuItem, Me.InstructionsExplorerMenuItem})
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(44, 20)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'CrawlInstructMenuItem
        '
        Me.CrawlInstructMenuItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.CrawlInstructMenuItem.Name = "CrawlInstructMenuItem"
        Me.CrawlInstructMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.CrawlInstructMenuItem.Text = "Crawl Instructions"
        '
        'GameNotesMenuItem
        '
        Me.GameNotesMenuItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.GameNotesMenuItem.Name = "GameNotesMenuItem"
        Me.GameNotesMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.GameNotesMenuItem.Text = "Game Notes"
        '
        'InstructionsExplorerMenuItem
        '
        Me.InstructionsExplorerMenuItem.Name = "InstructionsExplorerMenuItem"
        Me.InstructionsExplorerMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.InstructionsExplorerMenuItem.Text = "Instructions Explorer"
        '
        'RefreshButton
        '
        Me.RefreshButton.Location = New System.Drawing.Point(105, 138)
        Me.RefreshButton.Margin = New System.Windows.Forms.Padding(2)
        Me.RefreshButton.Name = "RefreshButton"
        Me.RefreshButton.Size = New System.Drawing.Size(76, 23)
        Me.RefreshButton.TabIndex = 1
        Me.RefreshButton.Text = "Refresh"
        Me.RefreshButton.UseVisualStyleBackColor = True
        '
        'SavedList
        '
        Me.SavedList.FormattingEnabled = True
        Me.SavedList.Location = New System.Drawing.Point(4, 17)
        Me.SavedList.Margin = New System.Windows.Forms.Padding(2)
        Me.SavedList.Name = "SavedList"
        Me.SavedList.Size = New System.Drawing.Size(79, 121)
        Me.SavedList.TabIndex = 2
        '
        'SavedGroupBox
        '
        Me.SavedGroupBox.Controls.Add(Me.SavedList)
        Me.SavedGroupBox.Location = New System.Drawing.Point(9, 24)
        Me.SavedGroupBox.Margin = New System.Windows.Forms.Padding(2)
        Me.SavedGroupBox.Name = "SavedGroupBox"
        Me.SavedGroupBox.Padding = New System.Windows.Forms.Padding(2)
        Me.SavedGroupBox.Size = New System.Drawing.Size(92, 145)
        Me.SavedGroupBox.TabIndex = 3
        Me.SavedGroupBox.TabStop = False
        Me.SavedGroupBox.Text = "Saved"
        '
        'BackupGroupBox
        '
        Me.BackupGroupBox.Controls.Add(Me.BackupList)
        Me.BackupGroupBox.Location = New System.Drawing.Point(185, 24)
        Me.BackupGroupBox.Margin = New System.Windows.Forms.Padding(2)
        Me.BackupGroupBox.Name = "BackupGroupBox"
        Me.BackupGroupBox.Padding = New System.Windows.Forms.Padding(2)
        Me.BackupGroupBox.Size = New System.Drawing.Size(92, 145)
        Me.BackupGroupBox.TabIndex = 4
        Me.BackupGroupBox.TabStop = False
        Me.BackupGroupBox.Text = "Backup"
        '
        'BackupList
        '
        Me.BackupList.FormattingEnabled = True
        Me.BackupList.Location = New System.Drawing.Point(4, 17)
        Me.BackupList.Margin = New System.Windows.Forms.Padding(2)
        Me.BackupList.Name = "BackupList"
        Me.BackupList.Size = New System.Drawing.Size(79, 121)
        Me.BackupList.TabIndex = 2
        '
        'MoveButton
        '
        Me.MoveButton.Location = New System.Drawing.Point(105, 60)
        Me.MoveButton.Margin = New System.Windows.Forms.Padding(2)
        Me.MoveButton.Name = "MoveButton"
        Me.MoveButton.Size = New System.Drawing.Size(76, 23)
        Me.MoveButton.TabIndex = 5
        Me.MoveButton.Text = "< Restore"
        Me.MoveButton.UseVisualStyleBackColor = True
        '
        'LoadButton
        '
        Me.LoadButton.Location = New System.Drawing.Point(105, 33)
        Me.LoadButton.Margin = New System.Windows.Forms.Padding(2)
        Me.LoadButton.Name = "LoadButton"
        Me.LoadButton.Size = New System.Drawing.Size(76, 23)
        Me.LoadButton.TabIndex = 7
        Me.LoadButton.Text = "Load"
        Me.LoadButton.UseVisualStyleBackColor = True
        '
        'FileProgress
        '
        Me.FileProgress.Location = New System.Drawing.Point(108, 87)
        Me.FileProgress.Margin = New System.Windows.Forms.Padding(2)
        Me.FileProgress.Name = "FileProgress"
        Me.FileProgress.Size = New System.Drawing.Size(72, 15)
        Me.FileProgress.TabIndex = 9
        Me.FileProgress.Visible = False
        '
        'StatusBar
        '
        Me.StatusBar.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StatusText})
        Me.StatusBar.Location = New System.Drawing.Point(0, 173)
        Me.StatusBar.Name = "StatusBar"
        Me.StatusBar.Padding = New System.Windows.Forms.Padding(1, 0, 10, 0)
        Me.StatusBar.Size = New System.Drawing.Size(284, 22)
        Me.StatusBar.SizingGrip = False
        Me.StatusBar.TabIndex = 10
        Me.StatusBar.Text = "StatusStrip1"
        '
        'StatusText
        '
        Me.StatusText.Name = "StatusText"
        Me.StatusText.Size = New System.Drawing.Size(39, 17)
        Me.StatusText.Text = "Ready"
        '
        'StatusTimer
        '
        Me.StatusTimer.Interval = 3000
        '
        'ScriptButton
        '
        Me.ScriptButton.Location = New System.Drawing.Point(105, 112)
        Me.ScriptButton.Margin = New System.Windows.Forms.Padding(2)
        Me.ScriptButton.Name = "ScriptButton"
        Me.ScriptButton.Size = New System.Drawing.Size(76, 23)
        Me.ScriptButton.TabIndex = 11
        Me.ScriptButton.Text = "Setup Script"
        Me.ScriptButton.UseVisualStyleBackColor = True
        '
        'CmdLineText
        '
        Me.CmdLineText.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.CmdLineText.Font = New System.Drawing.Font("Courier New", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdLineText.Location = New System.Drawing.Point(6, 19)
        Me.CmdLineText.Name = "CmdLineText"
        Me.CmdLineText.Size = New System.Drawing.Size(222, 21)
        Me.CmdLineText.TabIndex = 12
        Me.myToolTip.SetToolTip(Me.CmdLineText, "P(x) to push ""x"" key in new crawl, p(x) to push ""x"" in existing crawl.  use {ENTE" & _
                "R}, {ADD}, {LEFT}, {RIGHT}, {UP}, {DOWN}, {HOME}, {PGUP}, {END}, {PGDN}")
        '
        'CmdLineGroup
        '
        Me.CmdLineGroup.Controls.Add(Me.CmdLineButton)
        Me.CmdLineGroup.Controls.Add(Me.CmdLineText)
        Me.CmdLineGroup.Location = New System.Drawing.Point(9, 174)
        Me.CmdLineGroup.Name = "CmdLineGroup"
        Me.CmdLineGroup.Size = New System.Drawing.Size(268, 49)
        Me.CmdLineGroup.TabIndex = 13
        Me.CmdLineGroup.TabStop = False
        Me.CmdLineGroup.Text = "Command Line"
        Me.CmdLineGroup.Visible = False
        '
        'CmdLineButton
        '
        Me.CmdLineButton.Location = New System.Drawing.Point(235, 18)
        Me.CmdLineButton.Name = "CmdLineButton"
        Me.CmdLineButton.Size = New System.Drawing.Size(24, 23)
        Me.CmdLineButton.TabIndex = 13
        Me.CmdLineButton.Text = ">"
        Me.CmdLineButton.UseVisualStyleBackColor = True
        '
        'KillButton
        '
        Me.KillButton.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.KillButton.Location = New System.Drawing.Point(232, 174)
        Me.KillButton.Name = "KillButton"
        Me.KillButton.Size = New System.Drawing.Size(51, 20)
        Me.KillButton.TabIndex = 14
        Me.KillButton.Text = "Kill All"
        Me.KillButton.UseVisualStyleBackColor = True
        '
        'MainForm
        '
        Me.AcceptButton = Me.LoadButton
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 195)
        Me.Controls.Add(Me.KillButton)
        Me.Controls.Add(Me.ScriptButton)
        Me.Controls.Add(Me.FileProgress)
        Me.Controls.Add(Me.LoadButton)
        Me.Controls.Add(Me.MoveButton)
        Me.Controls.Add(Me.BackupGroupBox)
        Me.Controls.Add(Me.SavedGroupBox)
        Me.Controls.Add(Me.RefreshButton)
        Me.Controls.Add(Me.MainMenu)
        Me.Controls.Add(Me.StatusBar)
        Me.Controls.Add(Me.CmdLineGroup)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MainMenu
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.MaximizeBox = False
        Me.Name = "MainForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Crawl Bender"
        Me.MainMenu.ResumeLayout(False)
        Me.MainMenu.PerformLayout()
        Me.SavedGroupBox.ResumeLayout(False)
        Me.BackupGroupBox.ResumeLayout(False)
        Me.StatusBar.ResumeLayout(False)
        Me.StatusBar.PerformLayout()
        Me.CmdLineGroup.ResumeLayout(False)
        Me.CmdLineGroup.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MainMenu As System.Windows.Forms.MenuStrip
    Friend WithEvents FileMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolsMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NotesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BenderMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NewCharacterMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LaunchCrawlMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents RefreshButton As System.Windows.Forms.Button
    Friend WithEvents OptionsMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SavedList As System.Windows.Forms.ListBox
    Friend WithEvents SavedGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents BackupGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents BackupList As System.Windows.Forms.ListBox
    Friend WithEvents MoveCharacterMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DeleteCharacterMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ExitMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MoveButton As System.Windows.Forms.Button
    Friend WithEvents LoadButton As System.Windows.Forms.Button
    Friend WithEvents FixHPMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FixBothHPMPMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FixAllBackupMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FixGoldMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FixFoodMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FixAllLaunchMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CrystalBallMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FileProgress As System.Windows.Forms.ProgressBar
    Friend WithEvents StatusBar As System.Windows.Forms.StatusStrip
    Friend WithEvents StatusText As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents StatusTimer As System.Windows.Forms.Timer
    Friend WithEvents OpenNotesMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ManageNotesMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CrawlInstructMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GameNotesMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ClearBonesMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ScriptButton As System.Windows.Forms.Button
    Friend WithEvents ToolStripSeparator5 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ScriptSetupMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents KillCrawlsMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator6 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents OpenInNotepadMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OpenSavedFolderMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator7 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents CommandLineMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CmdLineText As System.Windows.Forms.TextBox
    Friend WithEvents CmdLineGroup As System.Windows.Forms.GroupBox
    Friend WithEvents CmdLineButton As System.Windows.Forms.Button
    Friend WithEvents myToolTip As System.Windows.Forms.ToolTip
    Friend WithEvents InstructionsExplorerMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents KillButton As System.Windows.Forms.Button

End Class
