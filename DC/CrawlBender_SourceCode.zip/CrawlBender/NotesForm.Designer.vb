<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class NotesForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.NotesTabs = New System.Windows.Forms.TabControl
        Me.ScrollsTab = New System.Windows.Forms.TabPage
        Me.ScrollsList = New System.Windows.Forms.ListBox
        Me.PotionsTab = New System.Windows.Forms.TabPage
        Me.PotionsList = New System.Windows.Forms.ListBox
        Me.RingsTab = New System.Windows.Forms.TabPage
        Me.RingsList = New System.Windows.Forms.ListBox
        Me.WandsTab = New System.Windows.Forms.TabPage
        Me.WandsList = New System.Windows.Forms.ListBox
        Me.AmuletsTab = New System.Windows.Forms.TabPage
        Me.AmuletsList = New System.Windows.Forms.ListBox
        Me.MiscTab = New System.Windows.Forms.TabPage
        Me.MiscList = New System.Windows.Forms.ListBox
        Me.Panel_Controls = New System.Windows.Forms.Panel
        Me.SaveBut = New System.Windows.Forms.Button
        Me.ContentLabel = New System.Windows.Forms.Label
        Me.TitleLabel = New System.Windows.Forms.Label
        Me.DeleteButton = New System.Windows.Forms.Button
        Me.Title = New System.Windows.Forms.TextBox
        Me.Content = New System.Windows.Forms.TextBox
        Me.UpdateButton = New System.Windows.Forms.Button
        Me.AddButton = New System.Windows.Forms.Button
        Me.NotesTabs.SuspendLayout()
        Me.ScrollsTab.SuspendLayout()
        Me.PotionsTab.SuspendLayout()
        Me.RingsTab.SuspendLayout()
        Me.WandsTab.SuspendLayout()
        Me.AmuletsTab.SuspendLayout()
        Me.MiscTab.SuspendLayout()
        Me.Panel_Controls.SuspendLayout()
        Me.SuspendLayout()
        '
        'NotesTabs
        '
        Me.NotesTabs.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.NotesTabs.Controls.Add(Me.ScrollsTab)
        Me.NotesTabs.Controls.Add(Me.PotionsTab)
        Me.NotesTabs.Controls.Add(Me.RingsTab)
        Me.NotesTabs.Controls.Add(Me.WandsTab)
        Me.NotesTabs.Controls.Add(Me.AmuletsTab)
        Me.NotesTabs.Controls.Add(Me.MiscTab)
        Me.NotesTabs.Location = New System.Drawing.Point(0, 0)
        Me.NotesTabs.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.NotesTabs.Name = "NotesTabs"
        Me.NotesTabs.SelectedIndex = 0
        Me.NotesTabs.Size = New System.Drawing.Size(378, 226)
        Me.NotesTabs.TabIndex = 0
        '
        'ScrollsTab
        '
        Me.ScrollsTab.Controls.Add(Me.ScrollsList)
        Me.ScrollsTab.Location = New System.Drawing.Point(4, 25)
        Me.ScrollsTab.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ScrollsTab.Name = "ScrollsTab"
        Me.ScrollsTab.Padding = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ScrollsTab.Size = New System.Drawing.Size(370, 197)
        Me.ScrollsTab.TabIndex = 0
        Me.ScrollsTab.Text = "Scrolls"
        Me.ScrollsTab.UseVisualStyleBackColor = True
        '
        'ScrollsList
        '
        Me.ScrollsList.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ScrollsList.FormattingEnabled = True
        Me.ScrollsList.IntegralHeight = False
        Me.ScrollsList.ItemHeight = 16
        Me.ScrollsList.Location = New System.Drawing.Point(3, 2)
        Me.ScrollsList.Name = "ScrollsList"
        Me.ScrollsList.Size = New System.Drawing.Size(364, 193)
        Me.ScrollsList.TabIndex = 0
        '
        'PotionsTab
        '
        Me.PotionsTab.Controls.Add(Me.PotionsList)
        Me.PotionsTab.Location = New System.Drawing.Point(4, 25)
        Me.PotionsTab.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.PotionsTab.Name = "PotionsTab"
        Me.PotionsTab.Size = New System.Drawing.Size(356, 197)
        Me.PotionsTab.TabIndex = 3
        Me.PotionsTab.Text = "Potions"
        Me.PotionsTab.UseVisualStyleBackColor = True
        '
        'PotionsList
        '
        Me.PotionsList.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PotionsList.FormattingEnabled = True
        Me.PotionsList.IntegralHeight = False
        Me.PotionsList.ItemHeight = 16
        Me.PotionsList.Location = New System.Drawing.Point(0, 0)
        Me.PotionsList.Name = "PotionsList"
        Me.PotionsList.Size = New System.Drawing.Size(356, 197)
        Me.PotionsList.TabIndex = 1
        '
        'RingsTab
        '
        Me.RingsTab.Controls.Add(Me.RingsList)
        Me.RingsTab.Location = New System.Drawing.Point(4, 25)
        Me.RingsTab.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.RingsTab.Name = "RingsTab"
        Me.RingsTab.Size = New System.Drawing.Size(356, 197)
        Me.RingsTab.TabIndex = 2
        Me.RingsTab.Text = "Rings"
        Me.RingsTab.UseVisualStyleBackColor = True
        '
        'RingsList
        '
        Me.RingsList.Dock = System.Windows.Forms.DockStyle.Fill
        Me.RingsList.FormattingEnabled = True
        Me.RingsList.IntegralHeight = False
        Me.RingsList.ItemHeight = 16
        Me.RingsList.Location = New System.Drawing.Point(0, 0)
        Me.RingsList.Name = "RingsList"
        Me.RingsList.Size = New System.Drawing.Size(356, 197)
        Me.RingsList.TabIndex = 2
        '
        'WandsTab
        '
        Me.WandsTab.Controls.Add(Me.WandsList)
        Me.WandsTab.Location = New System.Drawing.Point(4, 25)
        Me.WandsTab.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.WandsTab.Name = "WandsTab"
        Me.WandsTab.Padding = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.WandsTab.Size = New System.Drawing.Size(356, 197)
        Me.WandsTab.TabIndex = 1
        Me.WandsTab.Text = "Wands"
        Me.WandsTab.UseVisualStyleBackColor = True
        '
        'WandsList
        '
        Me.WandsList.Dock = System.Windows.Forms.DockStyle.Fill
        Me.WandsList.FormattingEnabled = True
        Me.WandsList.IntegralHeight = False
        Me.WandsList.ItemHeight = 16
        Me.WandsList.Location = New System.Drawing.Point(3, 2)
        Me.WandsList.Name = "WandsList"
        Me.WandsList.Size = New System.Drawing.Size(350, 193)
        Me.WandsList.TabIndex = 2
        '
        'AmuletsTab
        '
        Me.AmuletsTab.Controls.Add(Me.AmuletsList)
        Me.AmuletsTab.Location = New System.Drawing.Point(4, 25)
        Me.AmuletsTab.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.AmuletsTab.Name = "AmuletsTab"
        Me.AmuletsTab.Size = New System.Drawing.Size(356, 197)
        Me.AmuletsTab.TabIndex = 4
        Me.AmuletsTab.Text = "Amulets"
        Me.AmuletsTab.UseVisualStyleBackColor = True
        '
        'AmuletsList
        '
        Me.AmuletsList.Dock = System.Windows.Forms.DockStyle.Fill
        Me.AmuletsList.FormattingEnabled = True
        Me.AmuletsList.IntegralHeight = False
        Me.AmuletsList.ItemHeight = 16
        Me.AmuletsList.Location = New System.Drawing.Point(0, 0)
        Me.AmuletsList.Name = "AmuletsList"
        Me.AmuletsList.Size = New System.Drawing.Size(356, 197)
        Me.AmuletsList.TabIndex = 2
        '
        'MiscTab
        '
        Me.MiscTab.Controls.Add(Me.MiscList)
        Me.MiscTab.Location = New System.Drawing.Point(4, 25)
        Me.MiscTab.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.MiscTab.Name = "MiscTab"
        Me.MiscTab.Size = New System.Drawing.Size(356, 197)
        Me.MiscTab.TabIndex = 5
        Me.MiscTab.Text = "Misc"
        Me.MiscTab.UseVisualStyleBackColor = True
        '
        'MiscList
        '
        Me.MiscList.Dock = System.Windows.Forms.DockStyle.Fill
        Me.MiscList.FormattingEnabled = True
        Me.MiscList.IntegralHeight = False
        Me.MiscList.ItemHeight = 16
        Me.MiscList.Location = New System.Drawing.Point(0, 0)
        Me.MiscList.Name = "MiscList"
        Me.MiscList.Size = New System.Drawing.Size(356, 197)
        Me.MiscList.TabIndex = 2
        '
        'Panel_Controls
        '
        Me.Panel_Controls.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel_Controls.Controls.Add(Me.SaveBut)
        Me.Panel_Controls.Controls.Add(Me.ContentLabel)
        Me.Panel_Controls.Controls.Add(Me.TitleLabel)
        Me.Panel_Controls.Controls.Add(Me.DeleteButton)
        Me.Panel_Controls.Controls.Add(Me.Title)
        Me.Panel_Controls.Controls.Add(Me.Content)
        Me.Panel_Controls.Controls.Add(Me.UpdateButton)
        Me.Panel_Controls.Controls.Add(Me.AddButton)
        Me.Panel_Controls.Location = New System.Drawing.Point(4, 231)
        Me.Panel_Controls.Name = "Panel_Controls"
        Me.Panel_Controls.Size = New System.Drawing.Size(370, 102)
        Me.Panel_Controls.TabIndex = 9
        '
        'SaveBut
        '
        Me.SaveBut.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.SaveBut.Location = New System.Drawing.Point(283, 63)
        Me.SaveBut.Name = "SaveBut"
        Me.SaveBut.Size = New System.Drawing.Size(75, 28)
        Me.SaveBut.TabIndex = 11
        Me.SaveBut.Text = "Save"
        Me.SaveBut.UseVisualStyleBackColor = True
        '
        'ContentLabel
        '
        Me.ContentLabel.AutoSize = True
        Me.ContentLabel.Location = New System.Drawing.Point(5, 38)
        Me.ContentLabel.Name = "ContentLabel"
        Me.ContentLabel.Size = New System.Drawing.Size(74, 17)
        Me.ContentLabel.TabIndex = 10
        Me.ContentLabel.Text = "Desciption"
        '
        'TitleLabel
        '
        Me.TitleLabel.AutoSize = True
        Me.TitleLabel.Location = New System.Drawing.Point(5, 10)
        Me.TitleLabel.Name = "TitleLabel"
        Me.TitleLabel.Size = New System.Drawing.Size(45, 17)
        Me.TitleLabel.TabIndex = 9
        Me.TitleLabel.Text = "Name"
        '
        'DeleteButton
        '
        Me.DeleteButton.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DeleteButton.Location = New System.Drawing.Point(202, 63)
        Me.DeleteButton.Name = "DeleteButton"
        Me.DeleteButton.Size = New System.Drawing.Size(75, 28)
        Me.DeleteButton.TabIndex = 5
        Me.DeleteButton.Text = "Delete"
        Me.DeleteButton.UseVisualStyleBackColor = True
        '
        'Title
        '
        Me.Title.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Title.Location = New System.Drawing.Point(79, 7)
        Me.Title.Name = "Title"
        Me.Title.Size = New System.Drawing.Size(284, 22)
        Me.Title.TabIndex = 2
        '
        'Content
        '
        Me.Content.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Content.Location = New System.Drawing.Point(79, 35)
        Me.Content.Name = "Content"
        Me.Content.Size = New System.Drawing.Size(284, 22)
        Me.Content.TabIndex = 3
        '
        'UpdateButton
        '
        Me.UpdateButton.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.UpdateButton.Location = New System.Drawing.Point(121, 63)
        Me.UpdateButton.Name = "UpdateButton"
        Me.UpdateButton.Size = New System.Drawing.Size(75, 28)
        Me.UpdateButton.TabIndex = 6
        Me.UpdateButton.Text = "Update"
        Me.UpdateButton.UseVisualStyleBackColor = True
        '
        'AddButton
        '
        Me.AddButton.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.AddButton.Location = New System.Drawing.Point(40, 63)
        Me.AddButton.Name = "AddButton"
        Me.AddButton.Size = New System.Drawing.Size(75, 28)
        Me.AddButton.TabIndex = 4
        Me.AddButton.Text = "New"
        Me.AddButton.UseVisualStyleBackColor = True
        '
        'NotesForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(377, 337)
        Me.Controls.Add(Me.Panel_Controls)
        Me.Controls.Add(Me.NotesTabs)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow
        Me.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.MinimumSize = New System.Drawing.Size(335, 279)
        Me.Name = "NotesForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Notes"
        Me.NotesTabs.ResumeLayout(False)
        Me.ScrollsTab.ResumeLayout(False)
        Me.PotionsTab.ResumeLayout(False)
        Me.RingsTab.ResumeLayout(False)
        Me.WandsTab.ResumeLayout(False)
        Me.AmuletsTab.ResumeLayout(False)
        Me.MiscTab.ResumeLayout(False)
        Me.Panel_Controls.ResumeLayout(False)
        Me.Panel_Controls.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents NotesTabs As System.Windows.Forms.TabControl
    Friend WithEvents ScrollsTab As System.Windows.Forms.TabPage
    Friend WithEvents WandsTab As System.Windows.Forms.TabPage
    Friend WithEvents RingsTab As System.Windows.Forms.TabPage
    Friend WithEvents PotionsTab As System.Windows.Forms.TabPage
    Friend WithEvents AmuletsTab As System.Windows.Forms.TabPage
    Friend WithEvents MiscTab As System.Windows.Forms.TabPage
    Friend WithEvents Panel_Controls As System.Windows.Forms.Panel
    Friend WithEvents ContentLabel As System.Windows.Forms.Label
    Friend WithEvents TitleLabel As System.Windows.Forms.Label
    Friend WithEvents DeleteButton As System.Windows.Forms.Button
    Friend WithEvents Title As System.Windows.Forms.TextBox
    Friend WithEvents Content As System.Windows.Forms.TextBox
    Friend WithEvents UpdateButton As System.Windows.Forms.Button
    Friend WithEvents AddButton As System.Windows.Forms.Button
    Friend WithEvents ScrollsList As System.Windows.Forms.ListBox
    Friend WithEvents PotionsList As System.Windows.Forms.ListBox
    Friend WithEvents RingsList As System.Windows.Forms.ListBox
    Friend WithEvents WandsList As System.Windows.Forms.ListBox
    Friend WithEvents AmuletsList As System.Windows.Forms.ListBox
    Friend WithEvents MiscList As System.Windows.Forms.ListBox
    Friend WithEvents SaveBut As System.Windows.Forms.Button
End Class
