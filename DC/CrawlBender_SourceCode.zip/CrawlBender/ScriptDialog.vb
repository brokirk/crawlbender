Imports System.Windows.Forms
Imports CrawlBender.Script


Public Class ScriptDialog


#Region "Constants"

    Const HDR_CELL = 0
    Const VALUE_CELL = 1

    'index of row in grid
    Private Const BRIBE_REPS_INDX = 0
    Private Const BRIBE_PAUSE_INDX = 1

    Private Const CAST_SPELL_INDX = 0
    Private Const CAST_REPS_INDX = 1
    Private Const CAST_PAUSE_INDX = 2

    Private Const READ_SCROLL_INDX = 0
    Private Const READ_REPS_INDX = 1
    Private Const READ_PAUSE_INDX = 2

    Private Const MEMO_BOOK_INDX = 0
    Private Const MEMO_SPELL_INDX = 1
    Private Const MEMO_REPS_INDX = 2
    Private Const MEMO_PAUSE_INDX = 3

    Private Const ENVOKE_REPS_INDX = 0
    Private Const ENVOKE_PAUSE_INDX = 1

    Private Const QUAFF_POTIONS_INDX = 0
    Private Const QUAFF_REPS_INDX = 1
    Private Const QUAFF_PAUSE_INDX = 2

    Private Const AQUIRE_SCROLL_INDX = 0
    Private Const AQUIRE_THING_INDX = 1
    Private Const AQUIRE_REPS_INDX = 2
    Private Const AQUIRE_PAUSE_INDX = 3


#End Region



#Region "Properties"

    Private myScript As Script
    Public Property TheScript() As Script
        Get
            Return myScript
        End Get
        Set(ByVal value As Script)
            myScript = value
        End Set
    End Property

#End Region


    Public Sub New()

        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        'myScript = New Script

    End Sub



#Region "Control Events"

    Private Sub ScriptDialog_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        PopScriptList()
        'If TheScript Is Nothing Then
        '    ScriptList.SelectedIndex = Script.ScriptTypes.None
        'Else
        '    ScriptList.SelectedIndex = TheScript.ScriptType
        'End If
        If TheScript Is Nothing Then TheScript = New BribeScript
        ScriptList.SelectedIndex = TheScript.ScriptType
    End Sub

    Private Sub ScriptList_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ScriptList.SelectedIndexChanged
        PopParametersGrid(ScriptList.SelectedIndex)
    End Sub

    Private Sub RunButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RunButton.Click
        'Dim engine As New ScriptEngine(Me.Owner)
        'engine.RunScript(myScript)
    End Sub

    Private Sub SaveButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveButton.Click
        GetUserInput()
        Me.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.Close()
    End Sub

    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub

#End Region



#Region "Private Procedures"


    ''' <summary>
    ''' populate list with available scripts
    ''' </summary>
    Private Sub PopScriptList()
        With ScriptList
            .Items.Add("Bribe-a-Thon")
            .Items.Add("Read Scroll")
            .Items.Add("Memorize Spell")
            .Items.Add("Cast Spell")
            .Items.Add("Envoke")
            .Items.Add("Quaff")
            .Items.Add("Scroll of Aquirement")
        End With
    End Sub

    ''' <summary>
    ''' populate parameter grid based on selected script
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub PopParametersGrid(ByVal SelectedScript As ScriptTypes)

        PGrid.Rows.Clear()

        Select Case SelectedScript

            Case ScriptTypes.Bribe_a_Thon

                'If TheScript.Parameters.Count > 0 Then
                '    reps = TheScript.Parameters(ScriptEngine.BRIBE_REPS_INDX)
                '    pause = TheScript.Parameters(ScriptEngine.BRIBE_PAUSE_INDX)
                'End If
                'PGrid.Rows.Add(ScriptEngine.REPS_TEXT, reps)
                'PGrid.Rows.Add(ScriptEngine.PAUSE_TEXT, pause)
                If SelectedScript <> TheScript.ScriptType Then TheScript = New BribeScript
                PGrid.Rows.Add(ScriptEngine.REPS_TEXT, TheScript.Iterations)
                PGrid.Rows.Add(ScriptEngine.PAUSE_TEXT, TheScript.Pause_MS)


            Case ScriptTypes.ReadScroll

                'Dim scroll As String = ""
                'If TheScript.Parameters.Count > 0 Then
                '    scroll = TheScript.Parameters(ScriptEngine.READ_SCROLL_INDX)
                '    reps = TheScript.Parameters(ScriptEngine.READ_REPS_INDX)
                'End If
                If SelectedScript <> TheScript.ScriptType Then TheScript = New ReadScrollScript
                Dim scroll As String = CType(TheScript, ReadScrollScript).ScrollLetter
                PGrid.Rows.Add(ScriptEngine.SCROLL_TEXT, scroll)
                PGrid.Rows.Add(ScriptEngine.REPS_TEXT, TheScript.Iterations)
                PGrid.Rows.Add(ScriptEngine.PAUSE_TEXT, TheScript.Pause_MS)


            Case ScriptTypes.MemorizeSpell
                'Dim book As String = ""
                'Dim spell As String = ""
                'If TheScript.Parameters.Count > 0 Then
                '    book = TheScript.Parameters(ScriptEngine.MEMO_BOOK_INDX)
                '    spell = TheScript.Parameters(ScriptEngine.MEMO_SPELL_INDX)
                '    reps = TheScript.Parameters(ScriptEngine.MEMO_REPS_INDX)
                'End If
                If SelectedScript <> TheScript.ScriptType Then TheScript = New MemorizeSpellScript
                Dim book As String = CType(TheScript, MemorizeSpellScript).BookLetter
                Dim spell As String = CType(TheScript, MemorizeSpellScript).SpellLetter
                PGrid.Rows.Add(ScriptEngine.BOOK_TEXT, book)
                PGrid.Rows.Add(ScriptEngine.SPELL_TEXT, spell)
                PGrid.Rows.Add(ScriptEngine.REPS_TEXT, TheScript.Iterations)
                PGrid.Rows.Add(ScriptEngine.PAUSE_TEXT, TheScript.Pause_MS)


            Case ScriptTypes.CastSpell
                'Dim spell As String = ""
                'If TheScript.Parameters.Count > 0 Then
                '    spell = TheScript.Parameters(ScriptEngine.CAST_SPELL_INDX)
                '    reps = TheScript.Parameters(ScriptEngine.CAST_REPS_INDX)
                'End If
                If SelectedScript <> TheScript.ScriptType Then TheScript = New CastSpellScript
                Dim spell As String = CType(TheScript, CastSpellScript).SpellLetter
                PGrid.Rows.Add(ScriptEngine.SPELL_TEXT, spell)
                PGrid.Rows.Add(ScriptEngine.REPS_TEXT, TheScript.Iterations)
                PGrid.Rows.Add(ScriptEngine.PAUSE_TEXT, TheScript.Pause_MS)


            Case ScriptTypes.Envoke

                'If TheScript.Parameters.Count > 0 Then
                '    reps = TheScript.Parameters(ScriptEngine.ENVOKE_REPS_INDX)
                'End If
                'PGrid.Rows.Add(ScriptEngine.REPS_TEXT, reps)
                'PGrid.Rows.Add(ScriptEngine.PAUSE_TEXT, pause)
                If SelectedScript <> TheScript.ScriptType Then TheScript = New EnvokeScript
                PGrid.Rows.Add(ScriptEngine.REPS_TEXT, TheScript.Iterations)
                PGrid.Rows.Add(ScriptEngine.PAUSE_TEXT, TheScript.Pause_MS)


            Case ScriptTypes.Quaff

                'Dim potion As String = ""
                'pause = 2000
                'If TheScript.Parameters.Count > 0 Then
                '    potion = TheScript.Parameters(ScriptEngine.QUAFF_POTIONS_INDX)
                '    reps = TheScript.Parameters(ScriptEngine.QUAFF_REPS_INDX)
                'End If
                'PGrid.Rows.Add(ScriptEngine.POTIONS_TEXT, potion)
                'PGrid.Rows.Add(ScriptEngine.REPS_TEXT, reps)
                'PGrid.Rows.Add(ScriptEngine.PAUSE_TEXT, pause)
                If SelectedScript <> TheScript.ScriptType Then TheScript = New QuaffScript
                Dim potion As String = CType(TheScript, QuaffScript).PotionLetter
                Dim pause As Integer = TheScript.Pause_MS
                If pause <= 0 Then pause = 2000

                PGrid.Rows.Add(ScriptEngine.POTIONS_TEXT, potion)
                PGrid.Rows.Add(ScriptEngine.REPS_TEXT, TheScript.Iterations)
                PGrid.Rows.Add(ScriptEngine.PAUSE_TEXT, pause)


            Case ScriptTypes.ScrollOfAquirement
                'Dim scroll As String = ""
                'Dim thing As String = ""
                'pause = 1000
                'If TheScript.Parameters.Count > 0 Then
                '    scroll = TheScript.Parameters(ScriptEngine.AQUIRE_SCROLL_INDX)
                '    thing = TheScript.Parameters(ScriptEngine.AQUIRE_THING_INDX)
                '    reps = TheScript.Parameters(ScriptEngine.AQUIRE_REPS_INDX)
                'End If
                If SelectedScript <> TheScript.ScriptType Then TheScript = New ScrollOfAquirementScript
                Dim scroll As String = CType(TheScript, ScrollOfAquirementScript).ScrollLetter
                Dim thing As String = CType(TheScript, ScrollOfAquirementScript).ThingLetter
                Dim pause As Integer = TheScript.Pause_MS
                If pause <= 0 Then pause = 1000

                PGrid.Rows.Add(ScriptEngine.SCROLL_TEXT, scroll)
                PGrid.Rows.Add(ScriptEngine.THING_TEXT, thing)
                PGrid.Rows.Add(ScriptEngine.REPS_TEXT, TheScript.Iterations)
                PGrid.Rows.Add(ScriptEngine.PAUSE_TEXT, pause)

        End Select

        PGrid.Rows(0).Cells(VALUE_CELL).Selected = True
    End Sub

    Private Sub GetUserInput()

        'TheScript.ScriptType = ScriptList.SelectedIndex

        'TheScript.Parameters.Clear()
        Select Case ScriptList.SelectedIndex

            Case ScriptTypes.Bribe_a_Thon
                TheScript = New BribeScript
                'TheScript.Parameters.Add(PGrid.Rows(ScriptEngine.BRIBE_REPS_INDX).Cells(VALUE_CELL).Value)
                'TheScript.Parameters.Add(PGrid.Rows(ScriptEngine.BRIBE_PAUSE_INDX).Cells(VALUE_CELL).Value)
                TheScript.Iterations = PGrid.Rows(BRIBE_REPS_INDX).Cells(VALUE_CELL).Value
                TheScript.Pause_MS = PGrid.Rows(BRIBE_PAUSE_INDX).Cells(VALUE_CELL).Value


            Case ScriptTypes.ReadScroll
                'TheScript.Parameters.Add(PGrid.Rows(ScriptEngine.READ_SCROLL_INDX).Cells(VALUE_CELL).Value)
                'TheScript.Parameters.Add(PGrid.Rows(ScriptEngine.READ_REPS_INDX).Cells(VALUE_CELL).Value)
                'TheScript.Parameters.Add(PGrid.Rows(ScriptEngine.READ_PAUSE_INDX).Cells(VALUE_CELL).Value)
                TheScript = New ReadScrollScript
                CType(TheScript, ReadScrollScript).ScrollLetter = PGrid.Rows(READ_SCROLL_INDX).Cells(VALUE_CELL).Value
                TheScript.Iterations = PGrid.Rows(READ_REPS_INDX).Cells(VALUE_CELL).Value
                TheScript.Pause_MS = PGrid.Rows(READ_PAUSE_INDX).Cells(VALUE_CELL).Value

            Case ScriptTypes.MemorizeSpell
                'TheScript.Parameters.Add(PGrid.Rows(MEMO_BOOK_INDX).Cells(VALUE_CELL).Value)
                'TheScript.Parameters.Add(PGrid.Rows(MEMO_SPELL_INDX).Cells(VALUE_CELL).Value)
                'TheScript.Parameters.Add(PGrid.Rows(MEMO_REPS_INDX).Cells(VALUE_CELL).Value)
                'TheScript.Parameters.Add(PGrid.Rows(MEMO_PAUSE_INDX).Cells(VALUE_CELL).Value)
                TheScript = New MemorizeSpellScript
                CType(TheScript, MemorizeSpellScript).BookLetter = PGrid.Rows(MEMO_BOOK_INDX).Cells(VALUE_CELL).Value
                CType(TheScript, MemorizeSpellScript).SpellLetter = PGrid.Rows(MEMO_SPELL_INDX).Cells(VALUE_CELL).Value
                TheScript.Iterations = PGrid.Rows(MEMO_REPS_INDX).Cells(VALUE_CELL).Value
                TheScript.Pause_MS = PGrid.Rows(MEMO_PAUSE_INDX).Cells(VALUE_CELL).Value

            Case ScriptTypes.CastSpell
                'TheScript.Parameters.Add(PGrid.Rows(CAST_SPELL_INDX).Cells(VALUE_CELL).Value)
                'TheScript.Parameters.Add(PGrid.Rows(CAST_REPS_INDX).Cells(VALUE_CELL).Value)
                'TheScript.Parameters.Add(PGrid.Rows(CAST_PAUSE_INDX).Cells(VALUE_CELL).Value)
                TheScript = New CastSpellScript
                CType(TheScript, CastSpellScript).SpellLetter = PGrid.Rows(CAST_SPELL_INDX).Cells(VALUE_CELL).Value
                TheScript.Iterations = PGrid.Rows(CAST_REPS_INDX).Cells(VALUE_CELL).Value
                TheScript.Pause_MS = PGrid.Rows(CAST_PAUSE_INDX).Cells(VALUE_CELL).Value

            Case ScriptTypes.Envoke
                'TheScript.Parameters.Add(PGrid.Rows(ENVOKE_REPS_INDX).Cells(VALUE_CELL).Value)
                'TheScript.Parameters.Add(PGrid.Rows(ENVOKE_PAUSE_INDX).Cells(VALUE_CELL).Value)
                TheScript = New EnvokeScript
                TheScript.Iterations = PGrid.Rows(ENVOKE_REPS_INDX).Cells(VALUE_CELL).Value
                TheScript.Pause_MS = PGrid.Rows(ENVOKE_PAUSE_INDX).Cells(VALUE_CELL).Value

            Case ScriptTypes.Quaff
                TheScript = New QuaffScript
                CType(TheScript, QuaffScript).PotionLetter = PGrid.Rows(QUAFF_POTIONS_INDX).Cells(VALUE_CELL).Value
                TheScript.Iterations = PGrid.Rows(QUAFF_REPS_INDX).Cells(VALUE_CELL).Value
                TheScript.Pause_MS = PGrid.Rows(QUAFF_PAUSE_INDX).Cells(VALUE_CELL).Value

            Case ScriptTypes.ScrollOfAquirement
                TheScript = New ScrollOfAquirementScript
                CType(TheScript, ScrollOfAquirementScript).ScrollLetter = PGrid.Rows(AQUIRE_SCROLL_INDX).Cells(VALUE_CELL).Value
                CType(TheScript, ScrollOfAquirementScript).ThingLetter = PGrid.Rows(AQUIRE_THING_INDX).Cells(VALUE_CELL).Value
                TheScript.Iterations = PGrid.Rows(AQUIRE_REPS_INDX).Cells(VALUE_CELL).Value
                TheScript.Pause_MS = PGrid.Rows(AQUIRE_PAUSE_INDX).Cells(VALUE_CELL).Value

        End Select

    End Sub



#End Region


   
    
End Class
