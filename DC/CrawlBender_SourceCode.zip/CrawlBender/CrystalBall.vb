Public Class CrystalBall

    Private game1 As SavedGameFile
    Private game2 As SavedGameFile
    Private match As Integer = 0
    Private totalMatches As Integer = 0
    Private searchPos As Integer = -1

    Private _savedFilePath As String = ""
    Public Property SavedFilePath() As String
        Get
            Return _savedFilePath
        End Get
        Set(ByVal value As String)
            _savedFilePath = value
            Me.GamePathLabel.Text = value
        End Set
    End Property


#Region "Control Event Handlers"

    Private Sub Load1Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Load1Button.Click
        Load1Button.Enabled = False
        game1 = New SavedGameFile(SavedFilePath)
        PopList(ListBox1, game1)

        FindGroupBox.Enabled = True
        ChangeBytesGroup.Enabled = True

        Load1Button.Enabled = True
    End Sub

    Private Sub Load2Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Load2Button.Click
        Load2Button.Enabled = False
        game2 = New SavedGameFile(SavedFilePath)
        PopList(ListBox2, game2)
        Load2Button.Enabled = True
    End Sub

    Private Sub CompareButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CompareButton.Click

        Dim POS_PREFIX_LEN As Integer = "000  | ".Length

        CompareButton.Enabled = False
        totalMatches = 0
        CompareList.Items.Clear()

        For i As Integer = 0 To ListBox1.Items.Count - 1
            If ListBox1.Items(i) <> ListBox2.Items(i) Then

                'parse out value
                Dim str1 As String = ListBox1.Items(i)
                Dim val1 As Integer = CByte(str1.Substring(POS_PREFIX_LEN).Trim)

                Dim str2 As String = ListBox2.Items(i)
                Dim val2 As Integer = CByte(str2.Substring(POS_PREFIX_LEN).Trim)

                'calc diff
                Dim diff As Integer = val2 - val1

                'show diff
                'CompareList.Items.Add(ListBox2.Items(i))
                CompareList.Items.Add(diff)

                totalMatches += 1
            Else
                CompareList.Items.Add("")
            End If
        Next

        Me.TotalMatchesLabel.Text = "Matches = " & totalMatches
        CompareButton.Enabled = True

    End Sub


    '[line up controls]
    Private Sub ListBox1_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles ListBox1.KeyPress
        LineUpWith1()
    End Sub
    Private Sub ListBox1_MouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles ListBox1.MouseClick
        LineUpWith1()
    End Sub
    Private Sub ListBox2_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles ListBox2.KeyPress
        LineUpWith2()
    End Sub
    Private Sub ListBox2_MouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles ListBox2.MouseClick
        LineUpWith2()
    End Sub
    Private Sub CompareList_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles CompareList.Click
        LineUpWithCompareList()
    End Sub
    Private Sub CompareList_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles CompareList.KeyUp
        LineUpWithCompareList()
    End Sub


    '[find controls]
    Private Sub FindButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FindButton.Click
        Dim searchStr As String = FindText.Text
        If Not IsNumeric(searchStr) Then
            MainForm.Status("You can only search for byte values (0-255)")
            Exit Sub
        Else
            searchPos = -1
            Dim searchVal As Byte = CByte(searchStr)
            Dim i As Integer = Array.IndexOf(game1._fileContents, searchVal, searchPos + 1)

            If i <> -1 Then
                searchPos = i
                ListBox1.SelectedIndex = searchPos
            Else
                MainForm.Status("'" & searchVal & "' not found")
            End If

        End If

    End Sub


    '[Update Controls]
    Private Sub GetValueButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GetValueButton.Click

        ByteValue.Text = ""
        Dim index As Integer
        If IsNumeric(ByteNum.Text) Then
            index = CInt(ByteNum.Text)
            If index < 0 Or index > game1._fileContents.Length Then
                ByteNum.Focus()
                MessageBox.Show("Bad Byte Num")
            Else
                ByteValue.Text = game1._fileContents(index)
                ListBox1.SelectedIndex = index
            End If

        Else
            ByteNum.Focus()
            MessageBox.Show("Bad Byte Num")
        End If

    End Sub

    Private Sub SaveButton_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveButton.Click
        Dim index As Integer
        If IsNumeric(ByteNum.Text) Then
            index = CInt(ByteNum.Text)
            game1._fileContents(index) = CByte(ByteValue.Text)
            game1.Save()
        Else
            MessageBox.Show("Bad Byte Num")
        End If

    End Sub

    Private Sub FindNextButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FindNextButton.Click

        Dim searchVal As Byte = CByte(FindText.Text)
        Dim i As Integer = Array.IndexOf(game1._fileContents, searchVal, searchPos + 1)

        If i <> -1 Then
            searchPos = i
            ListBox1.SelectedIndex = searchPos
        Else
            MainForm.Status("'" & searchVal & "' not found")
        End If

    End Sub

    '[Nav controls]
    ''' <summary>
    ''' move to previous detected change
    ''' </summary>
    Private Sub PrevButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PrevButton.Click

        Dim startPos As Integer = IIf(CompareList.SelectedIndex >= 0, CompareList.SelectedIndex, 0) - 1

        For i As Integer = startPos To 0 Step -1
            'If CompareList.Items(i) <> "" Then
            If Not TypeOf (CompareList.Items(i)) Is String Then
                CompareList.SelectedIndex = i
                Exit For
            End If
        Next

        LineUpWithCompareList()
        match -= 1
        TotalMatchesLabel.Text = match & "/" & totalMatches

    End Sub

    ''' <summary>
    ''' Move to next detected change
    ''' </summary>
    Private Sub NextButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NextButton.Click

        Dim startPos As Integer = IIf(CompareList.SelectedIndex >= 0, CompareList.SelectedIndex, 0) + 1 'CInt(CurrentPosText.Text)

        For i As Integer = startPos To CompareList.Items.Count - 1
            If Not TypeOf (CompareList.Items(i)) Is String Then
                CompareList.SelectedIndex = i
                Exit For
            End If
        Next

        LineUpWithCompareList()

        match += 1
        TotalMatchesLabel.Text = match & "/" & totalMatches

    End Sub


    '[save controls]
    Private Sub SaveButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveCompareButton.Click
        Dim pos As Integer = Me.CompareList.SelectedIndex
        Dim val1 As String = ListBox1.Items(pos)
        Dim val2 As String = ListBox2.Items(pos)
        Dim compVal As String = CompareList.Items(pos)
        SavedList.Items.Add(Format(pos, "000") & " | " & val1 & " -> " & val2 & " = " & compVal)
    End Sub


#End Region



#Region "Private Procedures"

    Private Sub PopList(ByRef list As ListBox, ByRef game As SavedGameFile)
        With list
            .Items.Clear()
            Dim i As Integer = 0
            For Each b As Byte In game._fileContents
                .Items.Add(Format(i, "000") & "   |   " & b)
                '.Items.Add(b)
                i += 1
            Next
        End With
    End Sub

    Private Sub LineUpWith1()
        'line up other textboxes
        Dim i As Integer = ListBox1.SelectedIndex
        If i <= ListBox2.Items.Count - 1 Then ListBox2.SelectedIndex = i
        If i <= CompareList.Items.Count - 1 Then CompareList.SelectedIndex = i

        Me.CurrentPosText.Text = CompareList.SelectedIndex
    End Sub

    Private Sub LineUpWith2()
        'line up other textboxes
        Dim i As Integer = ListBox2.SelectedIndex
        If i <= ListBox1.Items.Count - 1 Then ListBox1.SelectedIndex = i
        If i <= CompareList.Items.Count - 1 Then CompareList.SelectedIndex = i

        Me.CurrentPosText.Text = CompareList.SelectedIndex
    End Sub

    Private Sub LineUpWithCompareList()
        'line up other textboxes
        Dim i As Integer = CompareList.SelectedIndex
        If i <= ListBox1.Items.Count - 1 Then ListBox1.SelectedIndex = i
        If i <= ListBox2.Items.Count - 1 Then ListBox2.SelectedIndex = i

        'display current position
        Me.CurrentPosText.Text = CompareList.SelectedIndex
    End Sub

#End Region

    
    
    
    
    
    
End Class