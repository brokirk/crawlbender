Imports System.IO.Path
Public Class MainForm

#Region "Constants"
    Const PERM_STATUS = -1
    Const EXPAND_HEIGHT = 280
    Const COMPACT_HEIGHT = 228
#End Region



#Region "private members"
    Private _crawl As DungeonCrawl
    Private _fileMan As CrawlFileManager
    Private _options As New GameOptions
    Private _script As Script
#End Region


#Region "Properties"

    Private _saveSelectedChar As String = ""
    ''' <summary>
    ''' Name of selected character
    ''' </summary>
    Public ReadOnly Property SelectedCharacter() As String
        Get
            Select Case Me.ListSelected
                Case Lists.Saved
                    Return SavedList.SelectedItem

                Case Lists.Backup
                    Return BackupList.SelectedItem

                Case Else
                    Return ""
            End Select
        End Get
    End Property

    Private Enum Lists
        Saved
        Backup
        None
    End Enum
    Private _listSelected As Lists = Lists.None
    Private Property ListSelected() As Lists
        Get
            Return _listSelected
        End Get
        Set(ByVal value As Lists)
            _listSelected = value

            'enable/disable controls 
            Select Case _listSelected

                Case Lists.Saved 'update menu text and buttons based on saved character being selected

                    '[File menu]
                    MoveCharacterMenuItem.Enabled = True
                    DeleteCharacterMenuItem.Enabled = True
                    MoveCharacterMenuItem.Text = "Backup Character"
                    DeleteCharacterMenuItem.Text = "Delete Saved Character"

                    '[Notes Menu]
                    OpenNotesMenuItem.Enabled = True

                    '[Fix Menu]
                    FixHPMenuItem.Enabled = True
                    FixBothHPMPMenuItem.Enabled = True
                    FixGoldMenuItem.Enabled = True
                    FixFoodMenuItem.Enabled = True
                    FixAllLaunchMenuItem.Enabled = True
                    FixAllBackupMenuItem.Enabled = True

                    '[Buttons]
                    LoadButton.Enabled = True
                    MoveButton.Visible = True
                    MoveButton.Text = "Backup >"
                    If Not Me.ScriptRunning Then ScriptButton.Enabled = True


                Case Lists.Backup 'update menu text and buttons based on backup character being selected

                    '[File menu]
                    MoveCharacterMenuItem.Enabled = True
                    DeleteCharacterMenuItem.Enabled = True
                    MoveCharacterMenuItem.Text = "Restore Character"
                    DeleteCharacterMenuItem.Text = "Delete Backup Character"

                    '[Notes Menu]
                    OpenNotesMenuItem.Enabled = True

                    '[Fix Menu]
                    FixHPMenuItem.Enabled = False
                    FixBothHPMPMenuItem.Enabled = False
                    FixGoldMenuItem.Enabled = False
                    FixFoodMenuItem.Enabled = False
                    FixAllLaunchMenuItem.Enabled = False
                    FixAllBackupMenuItem.Enabled = False

                    '[Buttons]
                    LoadButton.Enabled = False
                    MoveButton.Visible = True
                    MoveButton.Text = "< Restore"

                Case Lists.None 'disable menu options and buttons that require a selected character

                    '[File menu]
                    MoveCharacterMenuItem.Text = "Move Character"
                    MoveCharacterMenuItem.Enabled = False
                    DeleteCharacterMenuItem.Text = "Delete Character"
                    DeleteCharacterMenuItem.Enabled = False

                    '[Notes Menu]
                    OpenNotesMenuItem.Enabled = False

                    '[Fix Menu]
                    FixHPMenuItem.Enabled = False
                    FixBothHPMPMenuItem.Enabled = False
                    FixGoldMenuItem.Enabled = False
                    FixFoodMenuItem.Enabled = False
                    FixAllLaunchMenuItem.Enabled = False
                    FixAllBackupMenuItem.Enabled = False

                    '[Buttons]
                    LoadButton.Enabled = False
                    MoveButton.Visible = False
                    MoveButton.Text = "< Select >"
                    If Not Me.ScriptRunning Then ScriptButton.Enabled = False


            End Select
        End Set
    End Property

    Private _xl_path As String = ""
    ''' <summary>
    ''' find, save, and return the path to Excel.exe
    ''' </summary>
    Private ReadOnly Property xl_path() As String
        Get
            If _xl_path = "" Then


                'check for excel in a couple of places
                Const OFFICE9 = "C:\Program Files\Microsoft Office\OFFICE9\EXCEL.EXE"
                Const OFFICE10 = "C:\Program Files\Microsoft Office\OFFICE10\EXCEL.EXE"
                Const OFFICE11 = "C:\Program Files\Microsoft Office\OFFICE11\EXCEL.EXE"

                If My.Computer.FileSystem.FileExists(OFFICE11) Then
                    _xl_path = OFFICE11
                ElseIf My.Computer.FileSystem.FileExists(OFFICE10) Then
                    _xl_path = OFFICE10

                ElseIf My.Computer.FileSystem.FileExists(OFFICE9) Then
                    _xl_path = OFFICE9

                Else
                    'if still can't find then search all subfolders under \Program Files\
                    Status("Searching for Excel on your computer...", 60)
                    _xl_path = My.Computer.FileSystem.GetFiles("C:\Program Files\", FileIO.SearchOption.SearchAllSubDirectories, "excel.exe")(0)
                    Status("Excel Found, Opening...")
                End If

            End If
            Return _xl_path
        End Get
    End Property

    Private _scriptRunning As Boolean = False
    ''' <summary>
    ''' flag if script is currently running
    ''' </summary>
    Public ReadOnly Property ScriptRunning() As Boolean
        Get
            Return _scriptRunning
        End Get
    End Property

#End Region 'Properties



#Region "Public Methods"

    Public Sub New()

        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
    End Sub

    Public Sub LoadSavedGame()
        Status("Loading " & Me.SelectedCharacter & "...", 3)
        _crawl.Open(Me.SelectedCharacter)
    End Sub

    Public Sub FixGold()
        If Me.ListSelected = Lists.Saved Then
            Dim savedGame As New SavedGameFile(BuildSavedGameFname(Me.SelectedCharacter))
            savedGame.MaxGold()
            savedGame.Save()
            Status("Gold Fixed")
        End If
    End Sub

#End Region  'Public Methods



#Region "Control Events"

    Private Sub Main_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Activated
        RefreshLists()
    End Sub

    Private Sub Main_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.GotFocus

    End Sub

    '[Form Events]
    Private Sub Main_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Me.Location = My.Settings.StartupLocation

        'set form size
        Me.Height = COMPACT_HEIGHT

        ValidateSetup()

        _crawl = New DungeonCrawl(Me._options.GamePath)

        'check if crawl.exe is found
        Dim errStr As String = ""
        If Not _crawl.IsSetupValid(errStr) Then
            MessageBox.Show(errStr)
        End If

        _fileMan = New CrawlFileManager(_options.GamePath, _options.BackupPath)

        RefreshLists()


    End Sub

    Private Sub Main_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        My.Settings.StartupLocation = Me.Location
        My.Settings.Save()
    End Sub


    '[Listbox Events]

    ' only let a value in either saved list or backup list be selected (NOT BOTH!)
    Private Sub SavedList_MouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles SavedList.MouseClick
        BackupList.SelectedIndex = -1
        Me.ListSelected = Lists.Saved
    End Sub
    Private Sub BackupList_MouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles BackupList.MouseClick
        SavedList.SelectedIndex = -1
        Me.ListSelected = Lists.Backup
    End Sub

    Private Sub SavedList_MouseDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles SavedList.MouseDoubleClick
        _crawl.Open(Me.SelectedCharacter)
    End Sub

    Private Sub BackupList_MouseDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles BackupList.MouseDoubleClick
        Me.MoveCharacter()
    End Sub

    '[Buttons]
    Private Sub LoadButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LoadButton.Click
        Me.LoadSavedGame()
    End Sub

    Private Sub MoveButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MoveButton.Click
        MoveCharacter()
    End Sub

    Private Sub ScriptButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ScriptButton.Click

        ScriptButton.Enabled = False

        'check if script has been set up yet
        'If _script.ScriptType = Script.ScriptTypes.None Or _script.Parameters.Count <= 0 Then
        If _script Is Nothing Then
            SetupScript()
        Else
            _scriptRunning = True
            Status("Running Script " & _script.ScriptType.ToString)
            ScriptButton.Text = "Running..."
            Dim engine As New ScriptEngine(Me)
            With engine
                .RunScript(_script)
            End With
            ScriptButton.Text = "Run Script"
            _scriptRunning = False
        End If

        ScriptButton.Enabled = True

    End Sub

    Private Sub CmdLineButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdLineButton.Click

        Dim cmdLineString = Me.CmdLineText.Text

        If Trim(cmdLineString) <> "" Then
            ScriptButton.Enabled = False
            CmdLineButton.Enabled = False

            _scriptRunning = True
            Dim engine As New ScriptEngine(Me)
            engine.ParseCmdLine(cmdLineString)
            _scriptRunning = False

            ScriptButton.Enabled = True
            CmdLineButton.Enabled = True
        End If

    End Sub

    Private Sub RefreshButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RefreshButton.Click
        RefreshLists()
    End Sub

    Private Sub KillButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles KillButton.Click
        KillAllCrawls()
        LoadButton.Focus()
    End Sub


#End Region  'Control Events



#Region "Menu"

    ''[ File ]
    Private Sub NewCharacterMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NewCharacterMenuItem.Click
        Status("Launching Crawl...", 2)
        _crawl.Launch()
    End Sub

    Private Sub LaunchCrawlMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LaunchCrawlMenuItem.Click
        LoadSavedGame()
    End Sub

    ''' <summary>
    ''' Backup/Restore selected character - based on whether saved or backup character is selected
    ''' </summary>    
    ''' <remarks></remarks>
    Private Sub MoveCharacterMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MoveCharacterMenuItem.Click
        MoveCharacter()
    End Sub

    Private Sub DeleteCharacterMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DeleteCharacterMenuItem.Click
        DeleteCharacter()
    End Sub

    Private Sub ClearBonesMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClearBonesMenuItem.Click
        _fileMan.ClearBones()
        RefreshLists()
    End Sub

    Private Sub OpenSavedFolderMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OpenSavedFolderMenuItem.Click
        Shell("explorer.exe " & _options.GamePath, AppWinStyle.NormalFocus)
    End Sub

    Private Sub ExitMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitMenuItem.Click
        Me.Close()
    End Sub


    ''[Tools]
    Private Sub OptionsMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OptionsMenuItem.Click
        Dim options As New OptionsDialog(Me._options)
        options.ShowDialog()
    End Sub

    Private Sub CrystalBallMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CrystalBallMenuItem.Click
        Dim selChar As String = Me.SelectedCharacter
        If selChar <> "" Then
            Dim ball As New CrystalBall
            ball.SavedFilePath = BuildSavedGameFname(selChar)
            ball.Show()
            ball.Top = Me.Top + Me.Height + 2
            Dim L As Integer = Me.Left + Me.Width - ball.Width
            ball.Left = IIf(L > 0, L, 0)
        Else
            Status("Please select saved character first")
        End If
    End Sub

    Private Sub ScriptSetupMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ScriptSetupMenuItem.Click
        SetupScript()
    End Sub

    Private Sub KillCrawlsMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles KillCrawlsMenuItem.Click
        KillAllCrawls()
    End Sub

    Private Sub CommandLineMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CommandLineMenuItem.Click

        CommandLineMenuItem.Checked = Not CommandLineMenuItem.Checked

        'expand main form
        
        If CommandLineMenuItem.Checked Then
            Me.Height = EXPAND_HEIGHT
            CmdLineGroup.Visible = True
            Me.AcceptButton = CmdLineButton
            'load default commands --> offer on alter
            CmdLineText.Text = "p(w);p(e);p(E);p(p);p(,);p(Y)"
            CmdLineText.Focus()
        Else
            Me.Height = COMPACT_HEIGHT
            CmdLineGroup.Visible = False
            Me.AcceptButton = LoadButton
        End If



    End Sub


    '[ Notes ] 
    Private Sub OpenNotesMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OpenNotesMenuItem.Click

        Dim chrctr As String = Me.SelectedCharacter
        If chrctr <> "" Then

            'create notes form
            Dim notes As New NotesForm

            'load notes
            notes.LoadNotes(BuildNotesFname(chrctr))

            'show and position form
            Try
                notes.Show()
                notes.Top = Me.Top + Me.Height + 5
                Dim L As Integer = Me.Left + Me.Width - notes.Width
                notes.Left = IIf(L > 0, L, 0)
            Catch ex As ObjectDisposedException
                'ingore. this results when user cancels request to create new notes file.
            End Try

        End If

    End Sub

    Private Sub ManageNotesMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ManageNotesMenuItem.Click

        Dim notesMngr As New NotesManagerForm(_options.NotesPath)
        With notesMngr
            .Top = Me.Top
            .Left = Me.Left
            .Show(Me)
        End With
    End Sub

    Private Sub OpenInNotepadMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OpenInNotepadMenuItem.Click
        Dim chrctr As String = Me.SelectedCharacter
        If chrctr <> "" Then
            Dim fname = BuildNotesFname(chrctr)
            Shell("Notepad.exe " & fname, AppWinStyle.NormalFocus)
        End If

    End Sub

    ''[Help]
    Private Sub CrawlInstructMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CrawlInstructMenuItem.Click
        Shell("notepad " & Combine(_options.GamePath, GameOptions.INSTRUCT_FNAME), AppWinStyle.NormalFocus)
    End Sub

    Private Sub GameNotesMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GameNotesMenuItem.Click

        Dim path As String = xl_path & " " & """"c & _options.GameNotes & """"c
        Shell(path, AppWinStyle.NormalFocus)

    End Sub

    Private Sub InstructionsExplorerMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles InstructionsExplorerMenuItem.Click
        Dim path As String = Combine(My.Application.Info.DirectoryPath, "CrawlHelp.chm")
        MsgBox(path)
        'Shell(path, AppWinStyle.NormalFocus)
    End Sub


    ''[Bender]

    ''' <summary>
    ''' Max HP
    ''' </summary>
    Private Sub FixHPMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FixHPMenuItem.Click
        If Me.ListSelected = Lists.Saved Then
            Dim saved As New SavedGameFile(BuildSavedGameFname(Me.SelectedCharacter))
            saved.MaxHP()
            saved.Save()
            Status("HP Fixed")
        End If
    End Sub

    ''' <summary>
    ''' Max HP and MP
    ''' </summary>
    Private Sub FixBothHPMPMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FixBothHPMPMenuItem.Click
        If Me.ListSelected = Lists.Saved Then
            Dim saved As New SavedGameFile(BuildSavedGameFname(Me.SelectedCharacter))
            saved.MaxHP()
            saved.MaxMP()
            saved.Save()
            Status("HP & MP Fixed")
        End If
    End Sub

    ''' <summary>
    ''' Max HP and MP, Backup, Load
    ''' </summary>
    Private Sub FixAllBackupMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FixAllBackupMenuItem.Click
        If Me.ListSelected = Lists.Saved Then
            Dim chrctr As String = Me.SelectedCharacter
            Dim savedGame As New SavedGameFile(BuildSavedGameFname(chrctr))
            savedGame.MaxHP()
            savedGame.MaxMP()
            savedGame.Save()
            Status("HP & MP Fixed, Launching..., Backup...")
            _crawl.Open(chrctr)
            _fileMan.Backup(chrctr, Me.FileProgress)
        End If
    End Sub

    ''' <summary>
    ''' set gold to "big" value
    ''' </summary>
    Private Sub FixGoldMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FixGoldMenuItem.Click
        FixGold()
    End Sub

    ''' <summary>
    ''' set hunger level to barely Full
    ''' </summary>
    Private Sub FixFoodMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FixFoodMenuItem.Click
        If Me.ListSelected = Lists.Saved Then
            Dim savedGame As New SavedGameFile(BuildSavedGameFname(Me.SelectedCharacter))
            savedGame.FixFood()
            savedGame.Save()
            Status("Hunger Fixed")
        End If
    End Sub

    ''' <summary>
    ''' Max HP and MP, Load
    ''' </summary>
    ''' <remarks>don't backup</remarks>
    Private Sub FixAllLaunchMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FixAllLaunchMenuItem.Click
        If Me.ListSelected = Lists.Saved Then
            Dim chrctr As String = Me.SelectedCharacter
            Dim savedGame As New SavedGameFile(BuildSavedGameFname(chrctr))
            savedGame.MaxHP()
            savedGame.MaxMP()
            savedGame.Save()
            Status("HP & MP Fixed, Launching...")
            _crawl.Open(chrctr)
        End If
    End Sub

#End Region  'Menu



#Region "Status"

    Const DEFAULT_STATUS_TXT = "Ready"

    ''' <summary>
    ''' Display status message to user
    ''' </summary>
    Public Sub Status(ByVal Text As String, Optional ByVal DisplaySeconds As Integer = 7)

        StatusText.Text = Text

        ' if another value besides PERM_STATUS (-1) is passed then reset after DisplaySeconds seconds
        If DisplaySeconds > PERM_STATUS Then ResetStatusIn(DisplaySeconds)
    End Sub

    ''' <summary>
    ''' Reset the message in the status bar after x seconds
    ''' </summary>
    ''' <param name="Seconds">Number of seconds to wait before resetting the status bar text</param>
    Private Sub ResetStatusIn(ByVal Seconds As Integer)
        Const DEFAULT_WAIT_SECS = 7
        If Seconds <= 0 Then Seconds = DEFAULT_WAIT_SECS
        StatusTimer.Interval = Seconds * 1000
        StatusTimer.Enabled = True
    End Sub

    Private Sub StatusTimer_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StatusTimer.Tick
        StatusTimer.Enabled = False
        StatusText.Text = DEFAULT_STATUS_TXT
    End Sub

#End Region  'Status



#Region "Private Procedures"

    ''' <summary>
    ''' make sure file structure is valid
    ''' </summary>
    Private Sub ValidateSetup()
        With My.Computer.FileSystem

            'check if game path if found
            If Not .DirectoryExists(_options.GamePath) Then
                MessageBox.Show("The path " & vbLf & vbLf & _options.GamePath & vbLf & vbLf & "was not found", "Unable to find Game Path")
            End If

            'check if backup folder found
            If Not .DirectoryExists(_options.BackupPath) Then
                MessageBox.Show("The path " & vbLf & vbLf & _options.BackupPath & vbLf & vbLf & "was not found", "Unable to find Backup Path")
            End If

            'check if notes folder found
            If Not .DirectoryExists(_options.NotesPath) Then
                MessageBox.Show("The path " & vbLf & vbLf & _options.NotesPath & vbLf & vbLf & "was not found", "Unable to find Notes Path")
            End If

        End With
    End Sub

    ''' <summary>
    ''' Backup/Restore selected character - based on whether saved or backup character is selected
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub MoveCharacter()

        MoveButton.Enabled = False

        Dim chrctr As String = Me.SelectedCharacter
        Dim filesMoved As Integer = 0

        Select Case Me.ListSelected
            Case Lists.Saved
                Status("Backing up '" & chrctr & "'...", PERM_STATUS)
                StatusBar.Refresh()
                filesMoved = _fileMan.Backup(chrctr, Me.FileProgress)
                Status("'" & chrctr & "' backed up | files moved = " & filesMoved, PERM_STATUS)

            Case Lists.Backup
                Status("Restoring '" & chrctr & "'...")
                StatusBar.Refresh()
                filesMoved = _fileMan.Restore(chrctr, Me.FileProgress)
                Status("'" & chrctr & "' restored | files moved = " & filesMoved, PERM_STATUS)

            Case Lists.None
                Status("Must select Saved Or Backup Character first!")
        End Select

        RefreshLists()

        MoveButton.Enabled = True

    End Sub

    ''' <summary>
    ''' delete all files related to currently selected character
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub DeleteCharacter()

        Dim chrctr As String = Me.SelectedCharacter

        'determine if saved or backup list is selected
        Select Case Me.ListSelected

            Case Lists.Saved

                'doublecheck user wants to delete
                Dim response As DialogResult = MessageBox.Show("Are you sure you want to delete '" & chrctr & "'", "Delete Saved Game", MessageBoxButtons.OKCancel, MessageBoxIcon.Question)
                If response = Windows.Forms.DialogResult.OK Then
                    Status("Deleting " & chrctr & "...")
                    Dim filesDeleted As Integer = _fileMan.DeleteSavedCharacter(chrctr, FileProgress)
                    Status(chrctr & " deleted | files deleted = " & filesDeleted)
                Else
                    Exit Sub
                End If

            Case Lists.Backup

                'doublecheck user wants to delete
                Dim response As DialogResult = MessageBox.Show("Are you sure you want to delete '" & chrctr & "'", "Delete Backup Game", MessageBoxButtons.OKCancel, MessageBoxIcon.Question)
                If response = Windows.Forms.DialogResult.OK Then
                    Status("Deleting " & chrctr & "...")
                    Dim filesDeleted As Integer = _fileMan.DeleteBackupCharacter(chrctr, FileProgress)
                    Status(chrctr & " deleted | files deleted = " & filesDeleted)
                Else
                    Exit Sub
                End If

            Case Lists.None
                Status("Must select Saved Or Backup Character first!")

        End Select
        RefreshLists()
    End Sub


    ''' <summary>
    ''' populate saved and backup list with saved game names in respective folders
    ''' </summary>
    Private Sub RefreshLists()

        'save selected character so it can be restore after refresh
        If Me.ListSelected = Lists.Saved Then
            _saveSelectedChar = Me.SelectedCharacter
        Else
            _saveSelectedChar = ""
        End If

        PopAList(Me.SavedList, _options.GamePath)
        PopAList(Me.BackupList, _options.BackupPath)

        If _fileMan.BonesExist Then
            ClearBonesMenuItem.Enabled = True
        Else
            ClearBonesMenuItem.Enabled = False
        End If

        RestoreSelected()

    End Sub


    ''' <summary>
    ''' add all .sav file names (w/out extention) to a list box
    ''' </summary>
    ''' <param name="Box">Ref to list box to be populated</param>
    ''' <param name="SourceFolder">folder containing saved game files</param>
    Private Sub PopAList(ByRef Box As ListBox, ByVal SourceFolder As String)
        Box.Items.Clear()
        For Each f As String In My.Computer.FileSystem.GetFiles(SourceFolder)
            If f.EndsWith(".sav") Then
                Box.Items.Add(System.IO.Path.GetFileNameWithoutExtension(f))
            End If
        Next
    End Sub


    ''' <summary>
    ''' build character saved game file name 
    ''' </summary>
    ''' <param name="CharName">name of character</param>
    ''' <returns></returns>
    ''' <remarks>full name = game path + character name + .sav</remarks>
    Private Function BuildSavedGameFname(ByVal CharName As String) As String
        Return Combine(_options.GamePath, CharName) & ".sav"
    End Function


    ''' <summary>
    ''' build character notes file name
    ''' </summary>
    ''' <param name="CharName">name of character</param>
    ''' <returns></returns>
    ''' <remarks>full name = notes path + character name + _Notes.txt</remarks>
    Private Function BuildNotesFname(ByVal CharName As String) As String
        Return Combine(_options.NotesPath, CharName) & "_Notes.txt"
    End Function


    ''' <summary>
    ''' look for saveSelectedChar in saved list.  If found then select it
    ''' </summary>
    ''' <remarks>restores selected character in saved list after a list refresh</remarks>
    Private Sub RestoreSelected()

        'restore selected character if still in list
        Dim found As Boolean = False
        If _saveSelectedChar <> "" Then
            For i As Integer = 0 To SavedList.Items.Count - 1
                If SavedList.Items(i) = _saveSelectedChar Then
                    SavedList.SelectedIndex = i
                    Me.ListSelected = Lists.Saved
                    found = True
                    Exit For
                End If
            Next

        End If

        'if character was not restored/found then set ListSelected = None
        If Not found Then Me.ListSelected = Lists.None

    End Sub


    ''' <summary>
    ''' Show Script Config form
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetupScript()

        Dim scriptForm As New ScriptDialog
        'scriptForm.TheScript.DeepCopy(_script)
        scriptForm.TheScript = _script
        scriptForm.ShowDialog(Me)

        'scriptForm.Top = Me.Top + Me.Height + 2
        'Dim L As Integer = Me.Left + Me.Width - scriptForm.Width
        'scriptForm.Left = IIf(L > 0, L, 0)

        If scriptForm.DialogResult = Windows.Forms.DialogResult.OK Then
            '_script.DeepCopy(scriptForm.TheScript)
            _script = scriptForm.TheScript
            ScriptButton.Text = "Run Script"
        End If

    End Sub


    ''' <summary>
    ''' kill all crawl processes
    ''' </summary>
    Private Sub KillAllCrawls()

        '' kill them all with no questions asked, krw 10/3/12 
        'Dim result As DialogResult = MessageBox.Show("Are you sure you want to kill all Crawl sessions?", "Kill All Dungeon Crawls", MessageBoxButtons.OKCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1)
        'If result = Windows.Forms.DialogResult.OK Then
        Dim myProcesses As Process() = Process.GetProcessesByName("crawl")
        Dim myProcess As Process
        For Each myProcess In myProcesses
            myProcess.Kill()
        Next myProcess

        'End If

    End Sub




#End Region  'Private Procedures










































    
    
    
End Class






'''' <summary>
'''' return if a character is selected in the saved list
'''' </summary>
'Private ReadOnly Property IsSavedCharacterSelected() As Boolean
'    Get
'        If Me.SavedList.SelectedIndex >= 0 Then
'            Return True
'        Else
'            Return False
'        End If
'    End Get
'End Property

'''' <summary>
'''' return if character is selected in the backup list
'''' </summary>
'Private ReadOnly Property IsBackupCharacterSelected() As Boolean
'    Get
'        If Me.BackupList.SelectedIndex >= 0 Then
'            Return True
'        Else
'            Return False
'        End If
'    End Get
'End Property